/**
 * Parivar Furniture — Frontend Integrity Verification
 * Verifies that all original frontend files are byte-for-byte unchanged.
 * Run: node scripts/verify-frontend.js
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Original SHA-256 hashes computed BEFORE any backend work
const ORIGINAL_HASHES = {
  "README.md": "61399f18e56e2f8ac407e1b5f83203e3563075f66df0ac067bc8955c3dfe3d50",
  // NOTE: The full-stack project README is in FULLSTACK-README.md (a NEW file, not part of the immutable frontend)
  "_redirects": "f84dd46905d88e8b25e7ed750a64e918b0024205e6cd9c1b12e2099da879e9c5",
  "about.html": "7a80672ae1ca1639a4f52ebae8addd06413d36cd7e38e0f31a8c9b48e56282cb",
  "account.html": "74b583df7bc37331c3c7bf71e5baebd7de82c48dab684f2feb9b7659dcd7b0d6",
  "cart.html": "62cae626479d7f8c5ebfd804f2f741f8891dbf495507892e581b9657331e6727",
  "checkout.html": "50a1c31c782d5c7c419946fd3176ec03b8da4ec1831ff320fa35910e9ce0fc09",
  "contact.html": "c74e7062500551078c523fe753a6e96a1b820d14e93532d35e570386f633bd51",
  "index.html": "5c1e3b4e5da8ef62ae2f4dabff702b44d3d86a53695cf3aa97964b80671fb279",
  "netlify.toml": "f0f55b636a46898b5e240359dcb07fbaaa42c3a24538fd291cac3ebba69365fc",
  "order-success.html": "7ec7789ba8ab802cb061728c9a06e957c4d2a9c9a5cee5ceacd53c8f5871b099",
  "order-tracking.html": "755c7b62bdf14514efcaee9caacd088853a6c72614ea2ac2aedfcd338361805a",
  "product.html": "7e2c59c2d58ce032977065052049f0608b2efc9eaf8452cc1a70e44e9d64cea8",
  "shop.html": "633ba10ac4049a44cddcdcb3933b0eefe09adfd39a9e107e5039814d317ff0f3",
  "wishlist.html": "55a17666ac64f16e02c55237d7b90b1ba0562ea74024a5b1ada3256b4d449e2c",
  "css/styles.css": "3f59a4be20e9739c8231bd0a87b6fec472dca086469e721c10f8e00b3be6acdd",
  "js/cart.js": "09dbb3deeb232e39695ef1967118a71c4ac8a3cb5114e04f306c4e6f681c5dbc",
  "js/common.js": "d08769ec756ae08f1cd49359ba9751ecbb326d0894d7b6989dd82f7ed3e37e2b",
  "js/data.js": "2079a2848ff5a592f6e035c3135ce9a3db98637f50c5cc6f0b642402b4fba862"
};

const PROJECT_ROOT = path.resolve(__dirname, '..');

function sha256(filePath) {
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

function verify() {
  console.log('\n=== Frontend Integrity Verification ===\n');
  
  let passed = 0;
  let failed = 0;
  const results = {};

  for (const [file, expectedHash] of Object.entries(ORIGINAL_HASHES)) {
    const filePath = path.join(PROJECT_ROOT, file);
    
    if (!fs.existsSync(filePath)) {
      console.log(`  ✗ MISSING: ${file}`);
      results[file] = { original_hash: expectedHash, final_hash: null, status: 'MISSING' };
      failed++;
      continue;
    }

    const actualHash = sha256(filePath);
    
    if (actualHash === expectedHash) {
      console.log(`  ✓ ${file}`);
      results[file] = { original_hash: expectedHash, final_hash: actualHash, status: 'PASS' };
      passed++;
    } else {
      console.log(`  ✗ CHANGED: ${file}`);
      console.log(`    Expected: ${expectedHash}`);
      console.log(`    Actual:   ${actualHash}`);
      results[file] = { original_hash: expectedHash, final_hash: actualHash, status: 'FAIL' };
      failed++;
    }
  }

  console.log(`\n=== Results: ${passed} passed, ${failed} failed, ${passed + failed} total ===`);
  
  if (failed === 0) {
    console.log('✓ ALL FRONTEND FILES VERIFIED UNCHANGED\n');
  } else {
    console.log('✗ FRONTEND INTEGRITY CHECK FAILED\n');
    process.exit(1);
  }

  // Write frontend-integrity.json
  const report = {
    verified_at: new Date().toISOString(),
    total_files: passed + failed,
    passed,
    failed,
    status: failed === 0 ? 'PASS' : 'FAIL',
    files: results
  };

  const reportPath = path.join(PROJECT_ROOT, 'frontend-integrity.json');
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log(`Report written to: ${reportPath}`);

  return failed === 0;
}

verify();
