#!/bin/bash
# ============================================================
# PARIVAR FURNITURE — Build Script
# Runs during Netlify build to merge backend config with
# the immutable frontend config files.
#
# This does NOT modify the original _redirects or netlify.toml.
# Instead it generates COMBINED versions at build time.
# ============================================================

set -e

echo "=== Parivar Furniture Build ==="

# --- 1. Generate combined _redirects ---
# Keep original frontend redirects, add API routes
if [ -f "_redirects" ]; then
  cp _redirects _redirects.original.bak
fi

cat > _redirects << 'REDIRECTS'
# === API Routes (backend) ===
/api/products/*    /.netlify/functions/product-detail  200
/api/products      /.netlify/functions/products         200
/api/categories    /.netlify/functions/categories       200
/api/cart          /.netlify/functions/cart              200
/api/cart/*        /.netlify/functions/cart              200
/api/wishlist      /.netlify/functions/wishlist          200
/api/wishlist/*    /.netlify/functions/wishlist          200
/api/saved         /.netlify/functions/saved             200
/api/saved/*       /.netlify/functions/saved             200
/api/coupons       /.netlify/functions/coupons           200
/api/coupons/*     /.netlify/functions/coupons          200
/api/checkout      /.netlify/functions/checkout         200
/api/orders        /.netlify/functions/orders            200
/api/orders/*      /.netlify/functions/orders            200
/api/reviews       /.netlify/functions/reviews           200
/api/reviews/*     /.netlify/functions/reviews          200
/api/delivery      /.netlify/functions/delivery          200
/api/delivery/*    /.netlify/functions/delivery          200
/api/contact       /.netlify/functions/contact           200
/api/contact/*     /.netlify/functions/contact           200
/api/account       /.netlify/functions/account           200
/api/account/*     /.netlify/functions/account           200
/api/auth/*        /.netlify/functions/auth               200
/api/analytics     /.netlify/functions/analytics          200
/api/analytics/*   /.netlify/functions/analytics          200
/api/admin/*       /.netlify/functions/admin              200
/api/admin         /.netlify/functions/admin              200
/api/db-init       /.netlify/functions/db-init            200

# === Original Frontend Redirects (preserved from immutable _redirects) ===
/shop               /shop.html          200
/cart               /cart.html          200
/checkout           /checkout.html      200
/wishlist           /wishlist.html      200
/account            /account.html       200
/about              /about.html         200
/contact            /contact.html       200
/product            /product.html       200
/order-success      /order-success.html 200
/order-tracking     /order-tracking.html 200
/track-order        /order-tracking.html 200
/track              /order-tracking.html 200
/admin              /admin/index.html   200

# Optional trailing-slash variants
/shop/              /shop.html          200
/cart/              /cart.html          200
/checkout/          /checkout.html      200
/wishlist/          /wishlist.html      200
/account/           /account.html       200
/about/             /about.html         200
/contact/           /contact.html       200
/product/           /product.html       200
REDIRECTS

echo "✓ Combined _redirects generated"

# --- 2. Generate combined netlify.toml ---
# Preserve original headers, add functions + build config
cat > netlify.toml << 'TOML'
[build]
  command = "bash scripts/build.sh"
  functions = "netlify/functions"
  publish = "."

[functions]
  node_bundler = "esbuild"
  directory = "netlify/functions"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-Content-Type-Options = "nosniff"

[[headers]]
  for = "/css/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[headers]]
  for = "/js/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"

[[headers]]
  for = "/api/*"
  [headers.values]
    Access-Control-Allow-Origin = "*"
    Access-Control-Allow-Headers = "Content-Type, Authorization, X-Session-Id"
    Access-Control-Allow-Methods = "GET, POST, PATCH, PUT, DELETE, OPTIONS"

[[headers]]
  for = "/.netlify/functions/*"
  [headers.values]
    Access-Control-Allow-Origin = "*"
    Access-Control-Allow-Headers = "Content-Type, Authorization, X-Session-Id"
    Access-Control-Allow-Methods = "GET, POST, PATCH, PUT, DELETE, OPTIONS"
TOML

echo "✓ Combined netlify.toml generated"

# --- 3. Install function dependencies ---
if [ -f "netlify/functions/package.json" ]; then
  cd netlify/functions && npm install --production && cd ../..
  echo "✓ Function dependencies installed"
fi

# --- 4. Validate frontend integrity ---
if [ -f "scripts/verify-frontend.js" ]; then
  node scripts/verify-frontend.js
  echo "✓ Frontend integrity verified"
fi

echo "=== Build Complete ==="
