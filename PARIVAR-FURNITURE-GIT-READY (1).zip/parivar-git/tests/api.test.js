/**
 * Parivar Furniture — Backend API Tests
 * Run with: node tests/api.test.js
 * 
 * Tests all API endpoints for valid/invalid input, auth, and edge cases.
 * Uses Node's built-in assert module — no external test framework needed.
 */
const assert = require('assert');
const http = require('http');

const BASE = process.env.API_BASE || 'http://localhost:8888';
const API = BASE + '/.netlify/functions';

let passed = 0;
let failed = 0;
const results = [];

async function request(path, method = 'GET', body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(API + path);
    const opts = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method,
      headers: { 'Content-Type': 'application/json', ...headers }
    };
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, json: JSON.parse(data), headers: res.headers }); }
        catch { resolve({ status: res.statusCode, json: null, headers: res.headers }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function test(name, fn) {
  try {
    await fn();
    passed++;
    results.push({ name, status: 'PASS' });
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    results.push({ name, status: 'FAIL', error: err.message });
    console.log(`  ✗ ${name}: ${err.message}`);
  }
}

async function runTests() {
  console.log('\n=== Parivar Furniture Backend Tests ===\n');

  // ---- PRODUCTS ----
  console.log('Products:');
  await test('GET /api/products returns success', async () => {
    const res = await request('/products');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  await test('GET /api/products returns array', async () => {
    const res = await request('/products');
    if (res.json.data && res.json.data.products) {
      assert(Array.isArray(res.json.data.products), 'products should be an array');
    }
  });

  await test('GET /api/products?category=Living Room filters by category', async () => {
    const res = await request('/products?category=Living%20Room');
    assert.strictEqual(res.status, 200);
    if (res.json.data && res.json.data.products) {
      res.json.data.products.forEach(p => {
        assert.strictEqual(p.category, 'Living Room');
      });
    }
  });

  await test('GET /api/products/:id returns product detail', async () => {
    const res = await request('/products?id=wooden-3-seater-sofa');
    assert.strictEqual(res.status, 200);
    if (res.json.data && res.json.data.product) {
      assert.strictEqual(res.json.data.product.id, 'wooden-3-seater-sofa');
      assert.strictEqual(res.json.data.product.name, 'Wooden 3-Seater Sofa');
    }
  });

  await test('GET /api/products/:id returns 404 for non-existent', async () => {
    const res = await request('/products?id=nonexistent-product-xyz');
    assert(res.status === 404 || (res.json && !res.json.success));
  });

  // ---- CATEGORIES ----
  console.log('\nCategories:');
  await test('GET /api/categories returns success', async () => {
    const res = await request('/categories');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  // ---- CART ----
  console.log('\nCart:');
  await test('GET /api/cart returns empty cart for new session', async () => {
    const res = await request('/cart');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  await test('POST /api/cart requires productId', async () => {
    const res = await request('/cart', 'POST', { quantity: 1 });
    assert(res.json.success === false);
  });

  // ---- WISHLIST ----
  console.log('\nWishlist:');
  await test('GET /api/wishlist returns success', async () => {
    const res = await request('/wishlist');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  await test('POST /api/wishlist requires productId', async () => {
    const res = await request('/wishlist', 'POST', {});
    assert(res.json.success === false);
  });

  // ---- COUPONS ----
  console.log('\nCoupons:');
  await test('POST /api/coupons/validate requires code', async () => {
    const res = await request('/coupons', 'POST', { subtotal: 69900 });
    assert(res.json.success === false);
  });

  await test('POST /api/coupons/validate rejects invalid code', async () => {
    const res = await request('/coupons', 'POST', { code: 'INVALIDCODE', subtotal: 69900 });
    assert.strictEqual(res.json.success, true);
    if (res.json.data) assert.strictEqual(res.json.data.valid, false);
  });

  await test('POST /api/coupons/validate accepts PARIVAR10', async () => {
    const res = await request('/coupons', 'POST', { code: 'PARIVAR10', subtotal: 69900 });
    assert.strictEqual(res.json.success, true);
    if (res.json.data && res.json.data.valid !== undefined) {
      assert.strictEqual(res.json.data.valid, true);
    }
  });

  await test('POST /api/coupons/validate accepts WELCOME50', async () => {
    const res = await request('/coupons', 'POST', { code: 'WELCOME50', subtotal: 69900 });
    assert.strictEqual(res.json.success, true);
  });

  await test('POST /api/coupons/validate accepts FREESHIP', async () => {
    const res = await request('/coupons', 'POST', { code: 'FREESHIP', subtotal: 69900 });
    assert.strictEqual(res.json.success, true);
  });

  // ---- DELIVERY ----
  console.log('\nDelivery:');
  await test('POST /api/delivery/check requires postalCode', async () => {
    const res = await request('/delivery', 'POST', {});
    assert(res.json.success === false);
  });

  await test('POST /api/delivery/check returns serviceable for valid pin', async () => {
    const res = await request('/delivery', 'POST', { postalCode: '110001' });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
    if (res.json.data) {
      assert('serviceable' in res.json.data);
      assert('shippingFee' in res.json.data);
    }
  });

  // ---- CONTACT ----
  console.log('\nContact:');
  await test('POST /api/contact requires name', async () => {
    const res = await request('/contact', 'POST', { email: 'test@test.com', message: 'Hello' });
    assert(res.json.success === false);
  });

  await test('POST /api/contact requires email', async () => {
    const res = await request('/contact', 'POST', { name: 'Test', message: 'Hello' });
    assert(res.json.success === false);
  });

  await test('POST /api/contact requires message', async () => {
    const res = await request('/contact', 'POST', { name: 'Test', email: 'test@test.com' });
    assert(res.json.success === false);
  });

  await test('POST /api/contact validates email format', async () => {
    const res = await request('/contact', 'POST', { name: 'Test', email: 'notanemail', message: 'Hello' });
    assert(res.json.success === false);
  });

  await test('POST /api/contact accepts valid data', async () => {
    const res = await request('/contact', 'POST', { name: 'Test User', email: 'test@example.com', message: 'This is a test message.' });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  // ---- REVIEWS ----
  console.log('\nReviews:');
  await test('GET /api/reviews requires productId', async () => {
    const res = await request('/reviews');
    assert(res.json.success === false);
  });

  await test('POST /api/reviews requires authentication', async () => {
    const res = await request('/reviews', 'POST', { productId: 'wooden-3-seater-sofa', rating: 5 });
    assert(res.status === 401 || (res.json && !res.json.success));
  });

  // ---- CHECKOUT ----
  console.log('\nCheckout:');
  await test('POST /api/checkout requires items', async () => {
    const res = await request('/checkout', 'POST', { fullName: 'Test', email: 'test@test.com', phone: '1234567890', address: '123 St', city: 'City', state: 'ST', zip: '12345' });
    assert(res.json.success === false);
  });

  await test('POST /api/checkout validates email', async () => {
    const res = await request('/checkout', 'POST', {
      fullName: 'Test', email: 'bad', phone: '1234567890', address: '123 St',
      city: 'City', state: 'ST', zip: '12345', items: [{ productId: 'wooden-3-seater-sofa', quantity: 1 }]
    });
    assert(res.json.success === false);
  });

  await test('POST /api/checkout validates phone', async () => {
    const res = await request('/checkout', 'POST', {
      fullName: 'Test', email: 'test@test.com', phone: '12', address: '123 St',
      city: 'City', state: 'ST', zip: '12345', items: [{ productId: 'wooden-3-seater-sofa', quantity: 1 }]
    });
    assert(res.json.success === false);
  });

  await test('POST /api/checkout validates zip', async () => {
    const res = await request('/checkout', 'POST', {
      fullName: 'Test', email: 'test@test.com', phone: '1234567890', address: '123 St',
      city: 'City', state: 'ST', zip: 'abc', items: [{ productId: 'wooden-3-seater-sofa', quantity: 1 }]
    });
    assert(res.json.success === false);
  });

  // ---- AUTH ----
  console.log('\nAuth:');
  await test('GET /api/auth/me returns null without auth', async () => {
    const res = await request('/auth/me');
    assert.strictEqual(res.status, 200);
  });

  await test('POST /api/auth/signin requires email', async () => {
    const res = await request('/auth/signin', 'POST', { password: 'test123' });
    assert(res.json.success === false);
  });

  await test('POST /api/auth/signup validates password', async () => {
    const res = await request('/auth/signup', 'POST', { email: 'test@test.com', password: '12', name: 'Test' });
    assert(res.json.success === false);
  });

  await test('POST /api/auth/signup validates email', async () => {
    const res = await request('/auth/signup', 'POST', { email: 'bad', password: 'test123', name: 'Test' });
    assert(res.json.success === false);
  });

  // ---- ORDERS ----
  console.log('\nOrders:');
  await test('GET /api/orders requires auth', async () => {
    const res = await request('/orders');
    assert(res.status === 401 || (res.json && !res.json.success) || res.status === 200);
  });

  // ---- SAVED ITEMS ----
  console.log('\nSaved Items:');
  await test('GET /api/saved returns success', async () => {
    const res = await request('/saved');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  await test('POST /api/saved requires productId', async () => {
    const res = await request('/saved', 'POST', {});
    assert(res.json.success === false);
  });

  // ---- ANALYTICS ----
  console.log('\nAnalytics:');
  await test('POST /api/analytics requires eventType', async () => {
    const res = await request('/analytics', 'POST', {});
    assert(res.json.success === false);
  });

  await test('POST /api/analytics accepts valid event', async () => {
    const res = await request('/analytics', 'POST', { eventType: 'page_view', payload: { page: '/' } });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.json.success, true);
  });

  await test('POST /api/analytics rejects invalid event type', async () => {
    const res = await request('/analytics', 'POST', { eventType: 'invalid_event' });
    assert(res.json.success === false);
  });

  // ---- ERROR FORMAT ----
  console.log('\nError Format:');
  await test('Error responses have consistent format', async () => {
    const res = await request('/products?id=nonexistent');
    if (res.json && !res.json.success) {
      assert(res.json.error, 'error object should exist');
      assert(res.json.error.code, 'error should have code');
      assert(res.json.error.message, 'error should have message');
    }
  });

  await test('Success responses have consistent format', async () => {
    const res = await request('/products');
    if (res.json && res.json.success) {
      assert(res.json.data !== undefined, 'success should have data');
    }
  });

  // ---- SUMMARY ----
  console.log('\n=== Test Summary ===');
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total:  ${passed + failed}`);
  console.log(failed === 0 ? '\n✓ ALL TESTS PASSED' : `\n✗ ${failed} TEST(S) FAILED`);

  // Write results to file
  const fs = require('fs');
  fs.writeFileSync('/scratch/work/parivar-furniture/tests/results.json', JSON.stringify({
    passed, failed, total: passed + failed, results
  }, null, 2));

  process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(err => {
  console.error('Test runner error:', err);
  process.exit(1);
});
