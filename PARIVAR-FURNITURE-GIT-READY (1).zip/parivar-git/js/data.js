// Centralized product data — Parivar Furniture
const PRODUCTS = [
  {
    id: "wooden-3-seater-sofa",
    name: "Wooden 3-Seater Sofa",
    category: "Living Room",
    room: "living",
    price: 699,
    oldPrice: null,
    rating: 4.8,
    reviews: 124,
    material: "Solid Oak Wood",
    fabric: "Beige",
    availability: "In Stock",
    badge: "Best Seller",
    description: "Our 3-seater sofa is beautifully crafted from premium solid wood, designed to bring warmth, comfort, and elegance to your living space. Built with sturdy joinery and high-quality cushions for lasting comfort you can enjoy for years.",
    features: [
      "Premium solid wood frame for durability",
      "High-density foam cushions for superior comfort",
      "Removable cushion covers for easy cleaning",
      "Perfect for everyday use and modern living"
    ],
    specs: {
      dimensions: "W 210 cm × D 85 cm × H 85 cm",
      seating: "3 People",
      frame: "Solid Oak Wood",
      cushion: "High-Density Foam",
      weight: "45 kg",
      assembly: "Minimal Assembly Required"
    },
    images: [
      "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=80",
      "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=900&q=80",
      "https://images.unsplash.com/photo-1567016432779-094069958ea5?w=900&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=900&q=80"
    ],
    colors: [
      { name: "Beige", hex: "#E8DCC8" },
      { name: "Light Grey", hex: "#C4B5A0" },
      { name: "Charcoal", hex: "#6B6B6B" },
      { name: "Sage", hex: "#5A7A5A" }
    ],
    completeRoom: ["oak-coffee-table", "solid-wood-armchair", "wooden-sideboard"]
  },
  {
    id: "solid-wood-dining-table",
    name: "Solid Wood Dining Table",
    category: "Dining Room",
    room: "dining",
    price: 799,
    oldPrice: null,
    rating: 4.8,
    reviews: 98,
    material: "Oak Wood",
    fabric: null,
    availability: "In Stock",
    badge: null,
    description: "A timeless solid wood dining table that anchors your dining space with natural beauty and lasting strength. Crafted for family gatherings and everyday meals.",
    features: ["Solid oak construction", "Seats 6 comfortably", "Scratch-resistant finish", "Easy to clean surface"],
    specs: {
      dimensions: "W 180 cm × D 90 cm × H 75 cm",
      seating: "6 People",
      frame: "Solid Oak Wood",
      cushion: "—",
      weight: "52 kg",
      assembly: "Minimal Assembly Required"
    },
    images: [
      "https://images.unsplash.com/photo-1617806118233-18e1de247200?w=900&q=80",
      "https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?w=900&q=80",
      "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  },
  {
    id: "wooden-bed-frame",
    name: "Wooden Bed Frame",
    category: "Bedroom",
    room: "bedroom",
    price: 599,
    oldPrice: null,
    rating: 4.9,
    reviews: 177,
    material: "Solid Oak Wood",
    fabric: null,
    availability: "In Stock",
    badge: "Best Seller",
    description: "Sleep in comfort and style with our solid wood bed frame. Designed for durability and timeless elegance in your bedroom.",
    features: ["Solid wood construction", "Platform design — no box spring needed", "Strong support for all mattress types", "Natural wood finish"],
    specs: {
      dimensions: "W 160 cm × D 200 cm × H 100 cm",
      seating: "Queen Size",
      frame: "Solid Oak Wood",
      cushion: "—",
      weight: "48 kg",
      assembly: "Required"
    },
    images: [
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=900&q=80",
      "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=900&q=80",
      "https://images.unsplash.com/photo-1588046130717-6eb63bb3217d?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  },
  {
    id: "wooden-sideboard",
    name: "Wooden Sideboard",
    category: "Storage",
    room: "storage",
    price: 499,
    oldPrice: null,
    rating: 4.8,
    reviews: 82,
    material: "Natural Oak",
    fabric: null,
    availability: "In Stock",
    badge: null,
    description: "Elegant storage solution with ample space for dining essentials or living room display. Handcrafted solid wood sideboard.",
    features: ["Multiple storage compartments", "Solid wood doors and drawers", "Soft-close hinges", "Beautiful natural grain"],
    specs: {
      dimensions: "W 150 cm × D 45 cm × H 80 cm",
      seating: "—",
      frame: "Natural Oak",
      cushion: "—",
      weight: "38 kg",
      assembly: "Minimal"
    },
    images: [
      "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80",
      "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  },
  {
    id: "solid-wood-armchair",
    name: "Solid Wood Armchair",
    category: "Living Room",
    room: "living",
    price: 349,
    oldPrice: null,
    rating: 4.8,
    reviews: 64,
    material: "Oak Wood",
    fabric: "Beige",
    availability: "In Stock",
    badge: null,
    description: "A cozy solid wood armchair perfect for reading corners or accent seating. Comfortable and stylish.",
    features: ["Ergonomic design", "High-density cushion", "Solid wood frame", "Easy to move"],
    specs: {
      dimensions: "W 70 cm × D 75 cm × H 85 cm",
      seating: "1 Person",
      frame: "Oak Wood",
      cushion: "High-Density Foam",
      weight: "18 kg",
      assembly: "None"
    },
    images: [
      "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=900&q=80",
      "https://images.unsplash.com/photo-1592078615290-033ee584e267?w=900&q=80"
    ],
    colors: [{ name: "Beige", hex: "#E8DCC8" }],
    completeRoom: []
  },
  {
    id: "oak-coffee-table",
    name: "Oak Coffee Table",
    category: "Living Room",
    room: "living",
    price: 299,
    oldPrice: null,
    rating: 4.7,
    reviews: 86,
    material: "Oak Wood",
    fabric: null,
    availability: "In Stock",
    badge: "New",
    description: "A beautiful oak coffee table with clean lines and natural warmth. Perfect centerpiece for your living room.",
    features: ["Solid oak top", "Lower shelf for storage", "Sturdy legs", "Easy to clean"],
    specs: {
      dimensions: "W 110 cm × D 60 cm × H 45 cm",
      seating: "—",
      frame: "Oak Wood",
      cushion: "—",
      weight: "22 kg",
      assembly: "Minimal"
    },
    images: [
      "https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?w=900&q=80",
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  },
  {
    id: "wooden-tv-unit",
    name: "Wooden TV Unit",
    category: "Storage",
    room: "storage",
    price: 399,
    oldPrice: null,
    rating: 4.7,
    reviews: 53,
    material: "Natural Oak",
    fabric: null,
    availability: "In Stock",
    badge: null,
    description: "Sleek wooden TV unit with cable management and storage for media devices. Modern and functional.",
    features: ["Cable management system", "Open and closed storage", "Solid wood construction", "Supports large TVs"],
    specs: {
      dimensions: "W 160 cm × D 40 cm × H 50 cm",
      seating: "—",
      frame: "Natural Oak",
      cushion: "—",
      weight: "30 kg",
      assembly: "Required"
    },
    images: [
      "https://images.unsplash.com/photo-1615873968403-89e068629265?w=900&q=80",
      "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  },
  {
    id: "sheesham-bookshelf",
    name: "Sheesham Bookshelf",
    category: "Storage",
    room: "storage",
    price: 449,
    oldPrice: 529,
    rating: 4.6,
    reviews: 41,
    material: "Sheesham Wood",
    fabric: null,
    availability: "In Stock",
    badge: "Sale",
    description: "Tall solid Sheesham bookshelf with five spacious shelves. Perfect for books, decor and display.",
    features: ["Solid Sheesham wood", "Five adjustable shelves", "Anti-tip hardware included", "Natural grain finish"],
    specs: {
      dimensions: "W 90 cm × D 35 cm × H 180 cm",
      seating: "—",
      frame: "Sheesham Wood",
      cushion: "—",
      weight: "42 kg",
      assembly: "Required"
    },
    images: [
      "https://images.unsplash.com/photo-1594620302200-9a762244a156?w=900&q=80",
      "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80"
    ],
    colors: [],
    completeRoom: []
  }
];

const CATEGORIES = [
  { id: "living-room", name: "Living Room", room: "living", image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&q=80" },
  { id: "dining-room", name: "Dining Room", room: "dining", image: "https://images.unsplash.com/photo-1617806118233-18e1de247200?w=600&q=80" },
  { id: "bedroom", name: "Bedroom", room: "bedroom", image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=600&q=80" },
  { id: "storage", name: "Storage", room: "storage", image: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=600&q=80" }
];

const MEGA_MENU = {
  "Living Room": ["Sofas", "Armchairs", "Coffee Tables", "TV Units"],
  "Dining": ["Dining Tables", "Dining Chairs", "Cabinets"],
  "Bedroom": ["Bed Frames", "Bedside Tables", "Wardrobes"],
  "Storage": ["Sideboards", "Cabinets", "Shelving"]
};

const WHATSAPP_NUMBER = "919876543210";

function getProduct(id) {
  return PRODUCTS.find(p => p.id === id) || PRODUCTS[0];
}

function getProductsByCategory(cat) {
  if (!cat) return PRODUCTS;
  return PRODUCTS.filter(p => p.category === cat || p.room === cat.toLowerCase().replace(" ", "-"));
}
