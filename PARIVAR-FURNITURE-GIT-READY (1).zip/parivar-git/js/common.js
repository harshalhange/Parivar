// Shared header, footer, promo, search, cart drawer, mobile nav

function renderPromoBar() {
  return `
  <div class="promo-bar">
    <div class="promo-bar-inner">
      <a href="about.html" class="promo-item" style="color:inherit">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        Free Shipping on Orders Over $299
      </a>
      <a href="about.html" class="promo-item" style="color:inherit">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
        Made with Solid Wood
      </a>
      <a href="contact.html" class="promo-item" style="color:inherit">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
        30-Day Easy Returns
      </a>
    </div>
  </div>`;
}

function renderHeader(activePage = '') {
  return `
  <header class="header">
    <div class="header-inner">
      <a href="index.html" class="logo">
        <div class="logo-icon"></div>
        <div class="logo-text">PARIVAR<br><span>FURNITURE</span></div>
      </a>
      <nav class="nav">
        <a href="index.html" class="${activePage === 'home' ? 'active' : ''}">Home</a>
        <div class="nav-item-shop" style="position:relative">
          <a href="shop.html" class="${activePage === 'shop' ? 'active' : ''}">Shop</a>
          <div class="mega-menu">
            <div class="mega-inner">
              <div class="mega-col">
                <h4>Living Room</h4>
                <a href="shop.html?category=Living%20Room">Sofas</a>
                <a href="shop.html?category=Living%20Room">Armchairs</a>
                <a href="shop.html?category=Living%20Room">Coffee Tables</a>
                <a href="shop.html?category=Living%20Room">TV Units</a>
              </div>
              <div class="mega-col">
                <h4>Dining</h4>
                <a href="shop.html?category=Dining%20Room">Dining Tables</a>
                <a href="shop.html?category=Dining%20Room">Dining Chairs</a>
                <a href="shop.html?category=Dining%20Room">Cabinets</a>
              </div>
              <div class="mega-col">
                <h4>Bedroom</h4>
                <a href="shop.html?category=Bedroom">Bed Frames</a>
                <a href="shop.html?category=Bedroom">Bedside Tables</a>
                <a href="shop.html?category=Bedroom">Wardrobes</a>
              </div>
              <div class="mega-col">
                <h4>Storage</h4>
                <a href="shop.html?category=Storage">Sideboards</a>
                <a href="shop.html?category=Storage">Cabinets</a>
                <a href="shop.html?category=Storage">Shelving</a>
              </div>
              <div class="mega-promo">
                <img src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=400&q=80" alt="Collection">
                <div class="mega-promo-text"><a href="shop.html">Explore the Collection →</a></div>
              </div>
            </div>
          </div>
        </div>
        <a href="shop.html">Collections</a>
        <a href="about.html" class="${activePage === 'about' ? 'active' : ''}">About Us</a>
        <a href="contact.html" class="${activePage === 'contact' ? 'active' : ''}">Contact</a>
      </nav>
      <div class="header-actions">
        <button aria-label="Search" onclick="openSearch()">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        </button>
        <a href="wishlist.html" aria-label="Wishlist">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
        </a>
        <a href="account.html" aria-label="Account">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        </a>
        <a href="cart.html" aria-label="Cart" class="cart-link" onclick="event.preventDefault();openCartDrawer()">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
          <span class="cart-badge" style="display:none">0</span>
        </a>
        <button class="mobile-menu-btn" aria-label="Menu" onclick="toggleMobileMenu()">
          <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  </header>
  <div class="mobile-nav" id="mobileNav" onclick="if(event.target===this)toggleMobileMenu()">
    <div class="mobile-nav-panel">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <div class="logo-text" style="font-size:15px">PARIVAR<br><span>FURNITURE</span></div>
        <button onclick="toggleMobileMenu()" style="background:none;border:none;font-size:22px;color:var(--text)">×</button>
      </div>
      <a href="index.html">Home</a>
      <a href="shop.html">Shop</a>
      <a href="shop.html">Collections</a>
      <a href="about.html">About Us</a>
      <a href="contact.html">Contact</a>
      <a href="wishlist.html">Wishlist</a>
      <a href="cart.html">Cart</a>
      <a href="account.html">My Account</a>
      <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
        <a href="https://wa.me/${typeof WHATSAPP_NUMBER!=='undefined'?WHATSAPP_NUMBER:'919876543210'}" style="color:var(--primary-brown);font-weight:500">Chat on WhatsApp</a>
      </div>
    </div>
  </div>
  <!-- Search Overlay -->
  <div class="search-overlay" id="searchOverlay" onclick="if(event.target===this)closeSearch()">
    <div class="search-panel">
      <div class="search-panel-header">
        <input type="text" id="searchInput" placeholder="Search sofas, tables, beds, storage..." oninput="doSearch(this.value)" onkeydown="if(event.key==='Enter'){location.href='shop.html?q='+encodeURIComponent(this.value)}">
        <button class="search-close" onclick="closeSearch()">×</button>
      </div>
      <div class="popular-searches">
        Popular: 
        <span onclick="location.href='shop.html?q=sofa'">Sofa</span>
        <span onclick="location.href='shop.html?q=dining'">Dining Table</span>
        <span onclick="location.href='shop.html?q=bed'">Bed</span>
        <span onclick="location.href='shop.html?q=sideboard'">Sideboard</span>
        <span onclick="location.href='shop.html?q=tv'">TV Unit</span>
      </div>
      <div class="search-results" id="searchResults"></div>
    </div>
  </div>
  <!-- Cart Drawer -->
  <div class="cart-drawer-overlay" id="cartDrawer" onclick="if(event.target===this)closeCartDrawer()">
    <div class="cart-drawer">
      <div class="cart-drawer-header">
        <h3>Your Cart</h3>
        <button class="cart-drawer-close" onclick="closeCartDrawer()">×</button>
      </div>
      <div class="cart-drawer-body" id="cartDrawerBody"></div>
      <div class="cart-drawer-footer" id="cartDrawerFooter"></div>
    </div>
  </div>
  <!-- Mobile Bottom Nav -->
  <nav class="mobile-bottom-nav" aria-label="Mobile navigation">
    <a href="index.html" class="${activePage==='home'?'active':''}" aria-label="Home">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      Home
    </a>
    <a href="shop.html" class="${activePage==='shop'?'active':''}" aria-label="Shop">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M10 12h4"/><path d="M12 12v8"/></svg>
      Shop
    </a>
    <a href="wishlist.html" class="${activePage==='wishlist'?'active':''}" aria-label="Wishlist">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
      Wishlist
    </a>
    <a href="cart.html" class="${activePage==='cart'?'active':''}" onclick="event.preventDefault();openCartDrawer()" aria-label="Cart">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
      <span class="nav-badge cart-badge" style="display:none">0</span>
      Cart
    </a>
    <a href="account.html" class="${activePage==='account'?'active':''}" aria-label="Account">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Account
    </a>
  </nav>`;
}

function renderFooter() {
  return `
  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-brand">
        <div class="logo">
          <div class="logo-icon" style="background:radial-gradient(circle at 40% 40%,#A0673A,#7A451F 50%,#3B2415)"></div>
          <div class="logo-text">PARIVAR<br><span>FURNITURE</span></div>
        </div>
        <p>Bringing nature and craftsmanship together to create furniture you'll love for years.</p>
        <div class="social-links">
          <a href="#" aria-label="Facebook"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="#" aria-label="Instagram"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg></a>
          <a href="#" aria-label="Pinterest"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0a12 12 0 0 0-4.37 23.17c-.1-.94-.2-2.4.04-3.43l1.4-5.96s-.36-.72-.36-1.78c0-1.67.97-2.92 2.17-2.92 1.02 0 1.52.77 1.52 1.69 0 1.03-.66 2.57-1 4-.28 1.2.6 2.18 1.78 2.18 2.13 0 3.77-2.25 3.77-5.5 0-2.87-2.06-4.88-5-4.88-3.4 0-5.4 2.55-5.4 5.19 0 1.03.4 2.13.9 2.73.1.12.11.22.08.34l-.34 1.36c-.05.22-.18.27-.41.16-1.54-.72-2.5-2.97-2.5-4.78 0-3.9 2.83-7.48 8.16-7.48 4.28 0 7.61 3.05 7.61 7.13 0 4.25-2.68 7.67-6.4 7.67-1.25 0-2.42-.65-2.82-1.42l-.77 2.93c-.28 1.07-1.03 2.41-1.54 3.23A12 12 0 1 0 12 0z"/></svg></a>
        </div>
      </div>
      <div>
        <h4>Shop</h4>
        <div class="footer-links">
          <a href="shop.html">All Products</a>
          <a href="shop.html?category=Living%20Room">Living Room</a>
          <a href="shop.html?category=Dining%20Room">Dining Room</a>
          <a href="shop.html?category=Bedroom">Bedroom</a>
          <a href="shop.html?category=Storage">Storage</a>
        </div>
      </div>
      <div>
        <h4>Customer Service</h4>
        <div class="footer-links">
          <a href="#">Shipping Policy</a>
          <a href="#">Returns & Refunds</a>
          <a href="#">Terms & Conditions</a>
          <a href="#">Privacy Policy</a>
          <a href="contact.html">Contact Us</a>
        </div>
      </div>
      <div>
        <h4>Newsletter</h4>
        <p style="font-size:13.5px;color:rgba(248,244,236,0.7);margin-bottom:8px">Get updates on new arrivals and exclusive offers.</p>
        <form class="newsletter-form" onsubmit="event.preventDefault();showToast('✓ You\\'re subscribed!');this.reset();">
          <input type="email" placeholder="Enter your email" required>
          <button type="submit">Subscribe</button>
        </form>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Parivar Furniture. All Rights Reserved.</span>
    </div>
  </footer>`;
}

function toggleMobileMenu() {
  const nav = document.getElementById('mobileNav');
  if (!nav) return;
  const opening = !nav.classList.contains('open');
  nav.classList.toggle('open');
  document.body.classList.toggle('drawer-open', opening);
  if (!opening) document.body.style.position = '';
}
function openSearch() {
  document.getElementById('searchOverlay').classList.add('open');
  setTimeout(() => document.getElementById('searchInput').focus(), 100);
}
function closeSearch() {
  document.getElementById('searchOverlay').classList.remove('open');
}
function doSearch(q) {
  const el = document.getElementById('searchResults');
  if (!q || q.length < 2) { el.innerHTML = ''; return; }
  const results = (typeof PRODUCTS !== 'undefined' ? PRODUCTS : []).filter(p =>
    p.name.toLowerCase().includes(q.toLowerCase()) ||
    p.category.toLowerCase().includes(q.toLowerCase())
  ).slice(0, 6);
  el.innerHTML = results.map(p => `
    <a href="product.html?id=${p.id}" class="search-result-item">
      <img src="${p.images[0]}" alt="">
      <div>
        <h4>${p.name}</h4>
        <p>${p.category} · $${p.price}</p>
      </div>
    </a>
  `).join('') || '<p style="padding:12px;color:var(--text-sec);font-size:14px">No products found</p>';
}

function openCartDrawer() {
  renderCartDrawer();
  document.getElementById('cartDrawer').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCartDrawer() {
  const el = document.getElementById('cartDrawer');
  if (el) el.classList.remove('open');
  document.body.style.overflow = '';
  document.body.classList.remove('drawer-open');
}
function renderCartDrawer() {
  const items = Cart.get();
  const body = document.getElementById('cartDrawerBody');
  const footer = document.getElementById('cartDrawerFooter');
  if (!items.length) {
    body.innerHTML = `<div style="text-align:center;padding:40px 10px;color:var(--text-sec)">
      <p style="margin-bottom:16px">Your cart is empty</p>
      <a href="shop.html" class="btn btn-primary btn-sm" onclick="closeCartDrawer()">Explore Collection</a>
    </div>`;
    footer.innerHTML = '';
    return;
  }
  body.innerHTML = items.map(i => `
    <div class="cart-drawer-item">
      <img src="${i.image}" alt="">
      <div style="flex:1">
        <h4>${i.name}</h4>
        <p>Qty: ${i.quantity} · $${i.price * i.quantity}</p>
      </div>
    </div>
  `).join('');
  const sub = Cart.subtotal();
  footer.innerHTML = `
    <div class="subtotal"><span>Subtotal</span><span>$${sub.toFixed(2)}</span></div>
    <a href="cart.html" class="btn btn-outline btn-md btn-full" onclick="closeCartDrawer()">View Cart</a>
    <a href="checkout.html" class="btn btn-primary btn-md btn-full" onclick="closeCartDrawer()">Checkout</a>
  `;
}

function initLayout(activePage) {
  const promo = document.getElementById('promo-bar');
  const header = document.getElementById('site-header');
  const footer = document.getElementById('site-footer');
  if (promo) promo.innerHTML = renderPromoBar();
  if (header) header.innerHTML = renderHeader(activePage);
  if (footer) footer.innerHTML = renderFooter();
  Cart.updateBadge();
  window.scrollTo(0, 0);
  // Sticky header shrink
  window.addEventListener('scroll', () => {
    const h = document.querySelector('.header');
    if (h) h.classList.toggle('is-scrolled', window.scrollY > 40);
  }, { passive: true });
  // Fade-up observer
  if ('IntersectionObserver' in window) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.fade-up').forEach(el => obs.observe(el));
  }
}

// Escape key closes overlays
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeSearch();
    closeCartDrawer();
    const nav = document.getElementById('mobileNav');
    if (nav) nav.classList.remove('open');
  }
});
