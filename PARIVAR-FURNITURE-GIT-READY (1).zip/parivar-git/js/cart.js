// Parivar Cart · Wishlist · Recently Viewed · Promo · Save for Later
const Cart = {
  get() {
    try { return JSON.parse(localStorage.getItem('parivar_cart') || '[]'); }
    catch { return []; }
  },
  save(items) {
    localStorage.setItem('parivar_cart', JSON.stringify(items));
    this.updateBadge();
    window.dispatchEvent(new CustomEvent('cartUpdated'));
  },
  add(product, quantity = 1, variation = {}) {
    const items = this.get();
    const key = JSON.stringify(variation || {});
    const existing = items.find(i => i.id === product.id && JSON.stringify(i.variation || {}) === key);
    if (existing) existing.quantity += quantity;
    else {
      items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.images[0],
        quantity,
        variation: variation || {},
        category: product.category || '',
        material: product.material || '',
        fabric: product.fabric || (variation && variation.fabric) || ''
      });
    }
    this.save(items);
    showToast('✓ ' + product.name + ' added to cart');
    if (typeof openCartDrawer === 'function') setTimeout(() => openCartDrawer(), 280);
  },
  updateQty(id, quantity, variation = {}) {
    const items = this.get();
    const key = JSON.stringify(variation || {});
    const item = items.find(i => i.id === id && JSON.stringify(i.variation || {}) === key);
    if (item) {
      item.quantity = Math.max(1, quantity);
      this.save(items);
    }
  },
  remove(id, variation = {}) {
    const key = JSON.stringify(variation || {});
    const items = this.get().filter(i => !(i.id === id && JSON.stringify(i.variation || {}) === key));
    this.save(items);
    showToast('Removed from cart');
  },
  clear() { this.save([]); },
  count() { return this.get().reduce((s, i) => s + i.quantity, 0); },
  subtotal() { return this.get().reduce((s, i) => s + i.price * i.quantity, 0); },
  updateBadge() {
    const count = this.count();
    document.querySelectorAll('.cart-badge').forEach(b => {
      b.textContent = count;
      b.style.display = count > 0 ? 'flex' : 'none';
      if (count > 0) {
        b.classList.remove('bump');
        void b.offsetWidth;
        b.classList.add('bump');
      }
    });
  }
};

const Wishlist = {
  get() {
    try { return JSON.parse(localStorage.getItem('parivar_wishlist') || '[]'); }
    catch { return []; }
  },
  save(items) { localStorage.setItem('parivar_wishlist', JSON.stringify(items)); },
  toggle(productId) {
    let items = this.get();
    if (items.includes(productId)) {
      items = items.filter(id => id !== productId);
      showToast('Removed from wishlist');
    } else {
      items.push(productId);
      showToast('♡ Added to wishlist');
    }
    this.save(items);
    return items.includes(productId);
  },
  has(productId) { return this.get().includes(productId); },
  remove(productId) {
    this.save(this.get().filter(id => id !== productId));
    showToast('Removed from wishlist');
  }
};

const RecentlyViewed = {
  key: 'parivar_recently_viewed',
  max: 8,
  get() {
    try { return JSON.parse(localStorage.getItem(this.key) || '[]'); }
    catch { return []; }
  },
  add(productId) {
    let ids = this.get().filter(id => id !== productId);
    ids.unshift(productId);
    ids = ids.slice(0, this.max);
    localStorage.setItem(this.key, JSON.stringify(ids));
  },
  products() {
    const ids = this.get();
    if (typeof PRODUCTS === 'undefined') return [];
    return ids.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
  }
};

const SaveForLater = {
  key: 'parivar_saved_for_later',
  get() {
    try { return JSON.parse(localStorage.getItem(this.key) || '[]'); }
    catch { return []; }
  },
  save(items) { localStorage.setItem(this.key, JSON.stringify(items)); },
  add(item) {
    const items = this.get().filter(i => i.id !== item.id);
    items.push(item);
    this.save(items);
  },
  remove(id) {
    this.save(this.get().filter(i => i.id !== id));
  },
  moveToCart(id) {
    const items = this.get();
    const item = items.find(i => i.id === id);
    if (!item) return;
    this.remove(id);
    const product = typeof PRODUCTS !== 'undefined' ? PRODUCTS.find(p => p.id === id) : null;
    if (product) Cart.add(product, item.quantity || 1, item.variation || {});
  }
};

// Demo promo codes
const PROMO_CODES = {
  PARIVAR10: { type: 'percent', value: 10, label: '10% off' },
  WELCOME50: { type: 'fixed', value: 50, label: '$50 off' },
  FREESHIP: { type: 'shipping', value: 0, label: 'Free shipping' }
};

const Promo = {
  key: 'parivar_coupon',
  get() {
    try { return JSON.parse(localStorage.getItem(this.key) || 'null'); }
    catch { return null; }
  },
  apply(code) {
    const c = (code || '').trim().toUpperCase();
    const promo = PROMO_CODES[c];
    if (!promo) return { ok: false, message: 'That code couldn\'t be applied.' };
    localStorage.setItem(this.key, JSON.stringify({ code: c, ...promo }));
    return { ok: true, message: promo.label + ' applied', promo: { code: c, ...promo } };
  },
  clear() { localStorage.removeItem(this.key); },
  discount(subtotal) {
    const p = this.get();
    if (!p) return 0;
    if (p.type === 'percent') return Math.round(subtotal * p.value) / 100;
    if (p.type === 'fixed') return Math.min(p.value, subtotal);
    return 0;
  },
  freeShipping() {
    const p = this.get();
    return p && p.type === 'shipping';
  }
};

function showToast(message) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toast.classList.remove('show'), 2800);
}

function formatPrice(amount) {
  return '$' + Number(amount).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
function formatPriceDecimal(amount) {
  return '$' + Number(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function getProductById(id) {
  return typeof PRODUCTS !== 'undefined' ? PRODUCTS.find(p => p.id === id) : null;
}

function complementaryProducts(product) {
  if (!product || typeof PRODUCTS === 'undefined') return [];
  if (product.completeRoom && product.completeRoom.length) {
    return product.completeRoom.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
  }
  return PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);
}

document.addEventListener('DOMContentLoaded', () => Cart.updateBadge());
