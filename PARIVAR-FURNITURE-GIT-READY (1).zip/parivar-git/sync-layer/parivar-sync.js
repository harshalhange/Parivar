/**
 * Parivar Furniture — Frontend Sync Layer
 * 
 * This is a NON-INVASIVE compatibility layer that bridges the immutable
 * frontend's localStorage-based operations with the backend API.
 * 
 * It does NOT modify any original frontend files.
 * It is loaded AFTER the original scripts via a separate <script> tag
 * injected by Netlify's _redirects/headers configuration — OR included
 * as a new file that pages can optionally load.
 * 
 * Since the frontend is immutable and uses localStorage exclusively,
 * this sync layer provides:
 * 1. Background sync of localStorage cart/wishlist to server (when logged in)
 * 2. Server-side order creation via fetch to /api/checkout
 * 3. Analytics event tracking
 * 
 * It hooks into existing CustomEvent('cartUpdated') dispatched by cart.js
 * without modifying cart.js itself.
 */

(function() {
  'use strict';

  const API_BASE = '/.netlify/functions';
  let sessionId = null;
  let currentUser = null;

  // Get or create session ID for guest tracking
  function getSessionId() {
    if (sessionId) return sessionId;
    try {
      sessionId = localStorage.getItem('parivar_guest_sid');
      if (!sessionId) {
        sessionId = 'gs_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 12);
        localStorage.setItem('parivar_guest_sid', sessionId);
      }
    } catch { sessionId = 'gs_unknown'; }
    return sessionId;
  }

  // Safe fetch wrapper
  async function apiFetch(path, method, body) {
    try {
      const headers = { 'Content-Type': 'application/json' };
      const token = getCookie('parivar_session');
      if (token) headers['Authorization'] = 'Bearer ' + token;
      const opts = { method: method || 'GET', headers };
      if (body) opts.body = JSON.stringify(body);
      const res = await fetch(API_BASE + path, opts);
      return await res.json();
    } catch (err) {
      console.warn('[Parivar Sync] API error:', err);
      return { success: false, error: { message: 'Network error' } };
    }
  }

  function getCookie(name) {
    try {
      const cookies = document.cookie.split(';');
      for (const c of cookies) {
        const [k, ...v] = c.trim().split('=');
        if (k === name) return v.join('=');
      }
    } catch { return null; }
    return null;
  }

  // Track analytics events (non-blocking)
  function trackEvent(eventType, payload) {
    if (!navigator.onLine) return;
    apiFetch('/analytics', 'POST', { eventType, ...payload }).catch(() => {});
  }

  // ---- SYNC: Cart to server (when logged in) ----
  async function syncCartToServer() {
    try {
      const cartItems = JSON.parse(localStorage.getItem('parivar_cart') || '[]');
      if (cartItems.length === 0) return;
      // Only sync if user is authenticated
      const token = getCookie('parivar_session');
      if (!token) return;
      // Send each item to server cart
      for (const item of cartItems) {
        await apiFetch('/cart', 'POST', { productId: item.id, quantity: item.quantity });
      }
    } catch (err) {
      console.warn('[Parivar Sync] Cart sync failed:', err);
    }
  }

  // ---- SYNC: Wishlist to server (when logged in) ----
  async function syncWishlistToServer() {
    try {
      const token = getCookie('parivar_session');
      if (!token) return;
      const wishlist = JSON.parse(localStorage.getItem('parivar_wishlist') || '[]');
      for (const productId of wishlist) {
        await apiFetch('/wishlist', 'POST', { productId });
      }
    } catch (err) {
      console.warn('[Parivar Sync] Wishlist sync failed:', err);
    }
  }

  // ---- ENHANCED: Checkout via server API ----
  // Intercepts the existing placeOrder flow by listening for the
  // 'beforeunload' event on checkout.html — but since we can't modify
  // the frontend, we provide this as an OPTIONAL enhancement.
  // The original WhatsApp checkout still works perfectly without this.
  async function serverCheckout(formData, cartItems) {
    const payload = {
      fullName: formData.get('fullName'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      address: formData.get('address'),
      city: formData.get('city'),
      state: formData.get('state'),
      zip: formData.get('zip'),
      country: formData.get('country'),
      note: formData.get('note') || '',
      paymentMethod: formData.get('payment') || 'whatsapp',
      items: cartItems.map(i => ({ productId: i.id, quantity: i.quantity })),
      couponCode: (typeof Promo !== 'undefined' && Promo.get()) ? Promo.get().code : null
    };
    return apiFetch('/checkout', 'POST', payload);
  }

  // ---- INITIALIZATION ----
  function init() {
    // Track page views
    trackEvent('page_view', { page: location.pathname, title: document.title });

    // Listen for cart updates (dispatched by immutable cart.js)
    window.addEventListener('cartUpdated', () => {
      const items = JSON.parse(localStorage.getItem('parivar_cart') || '[]');
      trackEvent('add_to_cart', { itemCount: items.length });
      // Debounced sync
      clearTimeout(window._parivarSyncTimer);
      window._parivarSyncTimer = setTimeout(syncCartToServer, 2000);
    });

    // Track product views
    const params = new URLSearchParams(location.search);
    const productId = params.get('id');
    if (productId && location.pathname.includes('product')) {
      trackEvent('product_view', { productId });
    }

    // Track search
    const searchQuery = params.get('q');
    if (searchQuery && location.pathname.includes('shop')) {
      trackEvent('search', { query: searchQuery });
    }

    // Track checkout start
    if (location.pathname.includes('checkout')) {
      trackEvent('checkout_start', {});
    }

    // Expose serverCheckout for optional use
    window.ParivarSync = {
      serverCheckout,
      syncCartToServer,
      syncWishlistToServer,
      trackEvent,
      getSessionId
    };
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
