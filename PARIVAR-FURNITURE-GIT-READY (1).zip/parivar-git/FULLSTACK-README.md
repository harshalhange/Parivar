# Parivar Furniture — Full-Stack Ecommerce (Netlify + Supabase)

A complete production-ready ecommerce system built **around** an immutable frontend. The original frontend files remain byte-for-byte unchanged — all backend functionality is added via Netlify Functions, Supabase database, and a non-invasive sync layer.

## Quick Start

### 1. Prerequisites
- A [Supabase](https://supabase.com) account (free tier works)
- A [Netlify](https://netlify.com) account
- Node.js 18+

### 2. Database Setup (Zero Manual SQL)
1. Create a new Supabase project at https://app.supabase.com
2. Go to **Project Settings → API** and copy your:
   - Project URL (`SUPABASE_URL`)
   - Anon/Public key (`SUPABASE_ANON_KEY`)
   - Service Role key (`SUPABASE_SERVICE_ROLE_KEY`)
3. Go to the **SQL Editor** in Supabase
4. Run `database/schema/001_init.sql` (creates all tables)
5. Run `database/seeds/001_seed.sql` (seeds products, coupons, delivery zones)

### 3. Environment Configuration
```bash
cp .env.example .env
# Edit .env and fill in your Supabase credentials
```

### 4. Local Development
```bash
npm install
npx netlify dev
```
The site will be available at http://localhost:8888

### 5. Create Admin User
```bash
curl -X POST http://localhost:8888/.netlify/functions/auth/setup \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@parivarfurniture.com","password":"YourPassword123","name":"Admin"}'
```

### 6. Deploy to Netlify
```bash
# Option A: Netlify CLI
npm run build
npx netlify deploy --prod

# Option B: Git-based deploy
# Push this project to GitHub and connect it in Netlify dashboard
# Netlify will automatically run scripts/build.sh on every deploy
```

### 7. Configure Netlify Environment Variables
In Netlify dashboard → Site Settings → Environment Variables, add:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `AUTH_SECRET` (any random 64-character string)
- `WHATSAPP_NUMBER` (e.g., `919876543210`)
- `APP_URL` (your deployed URL)

## Architecture Overview

```
NETLIFY
├── Static Frontend (IMMUTABLE — original files unchanged)
│   ├── index.html, shop.html, product.html, cart.html, checkout.html
│   ├── wishlist.html, account.html, contact.html, about.html
│   ├── order-success.html, order-tracking.html
│   ├── css/styles.css, js/data.js, js/cart.js, js/common.js
│   └── _redirects (original, merged at build time)
│
├── Netlify Functions (Backend API)
│   ├── products.js, product-detail.js, categories.js
│   ├── cart.js, wishlist.js, saved.js
│   ├── coupons.js, checkout.js, orders.js
│   ├── delivery.js, contact.js, reviews.js
│   ├── auth.js, account.js, analytics.js
│   ├── admin.js, db-init.js
│   └── lib/ (shared: db, auth, validation, responses, security, money, logging)
│
├── Admin Panel (separate, non-invasive)
│   └── admin/index.html
│
├── Sync Layer (optional, non-invasive)
│   └── sync-layer/parivar-sync.js
│
├── Database (Supabase / PostgreSQL)
│   ├── database/schema/001_init.sql
│   └── database/seeds/001_seed.sql
│
├── Tests
│   └── tests/api.test.js
│
├── Scripts
│   ├── build.sh (generates combined _redirects and netlify.toml)
│   ├── deploy.sh (full deployment preparation)
│   └── verify-frontend.js (integrity verification)
│
└── Config
    ├── netlify.toml (generated at build time)
    ├── _redirects (generated at build time)
    ├── .env.example
    └── package.json
```

## Immutable Frontend Guarantee

The original frontend files are **never modified**. This is verified cryptographically:

```bash
npm run verify
```

This script computes SHA-256 hashes of all 18 original frontend files and compares them against the pre-recorded hashes in `scripts/verify-frontend.js`. The result is written to `frontend-integrity.json`.

**How the backend integrates without modifying the frontend:**

1. **Build-time config merge** — `scripts/build.sh` generates a combined `_redirects` and `netlify.toml` that includes both the original frontend routes and new API routes. The original files are preserved in the ZIP.

2. **Non-invasive sync layer** — `sync-layer/parivar-sync.js` hooks into the existing `cartUpdated` CustomEvent dispatched by the immutable `cart.js`, enabling background sync without any code changes.

3. **Server-authoritative checkout** — The backend `/api/checkout` endpoint validates all prices, stock, and totals server-side. The frontend's WhatsApp checkout continues to work exactly as before.

4. **Fallback mode** — All API endpoints gracefully handle the case where the database is not configured, returning demo/placeholder data so the frontend never breaks.

## Admin Access

The admin dashboard is at `/admin/` — a completely separate HTML file that does not touch the original frontend.

1. Create admin: `POST /api/auth/setup` (first run only)
2. Access: `https://your-site.netlify.app/admin/`
3. Login with your admin credentials

## API Endpoints

See [API.md](API.md) for complete endpoint documentation.

## Database Schema

See [DATABASE.md](DATABASE.md) for complete schema documentation.

## Architecture Details

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed architecture documentation.

## Testing

```bash
# Start the dev server first
npx netlify dev

# Run tests in another terminal
npm test
```

Tests cover: product fetch, product detail, cart, coupon validation, checkout validation, delivery check, contact form, reviews auth, auth flows, analytics, and error format consistency.

## Frontend Integrity

The `frontend-integrity.json` file (generated by `npm run verify`) contains:
- SHA-256 hash of each original frontend file (before and after)
- Status: PASS/FAIL for each file
- Total count of verified files

## Known External Requirements

The only manual step required is creating a Supabase project and copying 3 environment variables. This is unavoidable because:
1. Supabase requires account registration (cannot be auto-provisioned)
2. Database credentials are secrets that cannot be generated by the build system

Once those 3 variables are set, everything else is automatic:
- Schema creation (run SQL in Supabase editor)
- Seed data (run SQL in Supabase editor)
- Admin user creation (POST /api/auth/setup)
- All API endpoints work immediately

## Tech Stack

- **Frontend**: Static HTML/CSS/JS (immutable, as supplied)
- **Backend**: Netlify Functions (Node.js serverless)
- **Database**: Supabase (PostgreSQL)
- **Auth**: Custom JWT with bcrypt password hashing
- **Admin**: Standalone HTML dashboard
- **Deployment**: Netlify

## License

This is a project-specific build for Parivar Furniture.
