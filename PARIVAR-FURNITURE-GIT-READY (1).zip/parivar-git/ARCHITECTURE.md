# Architecture — Parivar Furniture Full-Stack

## Overview

The Parivar Furniture full-stack system is built on a **non-invasive integration** principle: the original frontend is 100% immutable, and all backend functionality is layered around it using serverless infrastructure.

## Core Constraints

1. **Frontend files are immutable** — 18 original files (HTML, CSS, JS, config) are never modified. SHA-256 hashes are verified before and after build.

2. **Zero manual setup** — Everything is auto-generated. The only unavoidable manual step is creating a Supabase project (requires account registration).

3. **Server-authoritative** — All money calculations, inventory, coupons, and orders are validated server-side. The browser cannot override prices, stock, or totals.

## System Architecture

```
┌─────────────────────────────────────────────────────┐
│                    NETLIFY PLATFORM                  │
│                                                      │
│  ┌──────────────┐   ┌──────────────────────────┐   │
│  │   Static CDN  │   │   Netlify Functions       │   │
│  │               │   │   (Node.js serverless)    │   │
│  │  Frontend     │   │                           │   │
│  │  (immutable)  │   │  /api/products            │   │
│  │               │   │  /api/cart                │   │
│  │  HTML/CSS/JS  │   │  /api/checkout            │   │
│  │  localStorage │   │  /api/orders              │   │
│  │  WhatsApp chk │   │  /api/auth                │   │
│  │               │   │  /api/admin               │   │
│  │  Admin Panel   │   │  /api/reviews             │   │
│  │  (separate)   │   │  /api/coupons             │   │
│  │               │   │  /api/delivery            │   │
│  └───────┬───────┘   └──────────┬───────────────┘   │
│          │                      │                    │
│          │   fetch (CORS)        │                   │
│          └──────────────────────┘                    │
│                                  │                    │
│  ┌───────────────────────────────┘                   │
│  │                                                    │
│  ▼                                                    │
│  ┌──────────────────────────────────────┐            │
│  │          SUPABASE (PostgreSQL)        │            │
│  │                                       │            │
│  │  users, products, orders, carts,     │            │
│  │  wishlists, coupons, reviews,        │            │
│  │  delivery_zones, analytics_events... │            │
│  └──────────────────────────────────────┘            │
└─────────────────────────────────────────────────────┘
```

## Data Flow

### Product Browsing
```
Frontend (js/data.js)     → renders products from local PRODUCTS array
Backend (/api/products)  → serves same products from database
                         → available for future headless usage
```
The frontend uses its own `PRODUCTS` array from `js/data.js` for rendering. The backend mirrors this data in PostgreSQL, making it available via API for future use (headless, mobile app, admin panel) without requiring frontend changes.

### Cart Operations
```
Frontend (js/cart.js)     → localStorage 'parivar_cart'
                         → dispatches CustomEvent('cartUpdated')
Sync Layer (parivar-sync) → listens for 'cartUpdated'
                         → background syncs to /api/cart (when logged in)
Backend (/api/cart)       → server-side cart persistence
```

### Checkout (Server-Authoritative)
```
Frontend (checkout.html)  → builds WhatsApp message
                         → opens wa.me link
                         → calls saveDemoOrder() → localStorage

Backend (/api/checkout)   → validates cart items
                         → resolves prices from DB (never trusts client)
                         → validates stock availability
                         → calculates totals (subtotal, discount, shipping, tax)
                         → creates order with price snapshots
                         → updates inventory atomically
                         → records coupon redemption
                         → returns order + WhatsApp URL
```

### Authentication
```
Frontend (account.html)   → localStorage 'parivar_user' (demo login)
Backend (/api/auth)       → signup, signin, signout
                         → JWT session tokens in HTTP-only cookies
                         → bcrypt password hashing
                         → role-based authorization (customer/admin)
```

## Integration Strategy

The backend adapts to the frontend, not the other way around:

1. **Build-time config merge** — `scripts/build.sh` generates a combined `_redirects` file that includes both the original frontend URL rewrites and new `/api/*` routes pointing to Netlify Functions. The original `_redirects` is preserved unchanged in the ZIP.

2. **Graceful fallback** — Every API endpoint checks `isConfigured()` and returns demo/placeholder data if the database isn't set up. This means the frontend continues to work perfectly even without a database.

3. **Non-invasive sync** — The sync layer (`sync-layer/parivar-sync.js`) hooks into the existing `CustomEvent('cartUpdated')` dispatched by the immutable `cart.js`. It runs entirely as an additional script — no existing files are modified.

4. **Separate admin** — The admin panel at `/admin/index.html` is a completely standalone HTML file with its own styles and scripts. It does not reference or modify any original frontend file.

## Security Architecture

| Concern              | Implementation                                      |
|---------------------|------------------------------------------------------|
| Passwords           | bcrypt hashing (10 rounds)                           |
| Sessions            | HMAC-signed JWT tokens in HTTP-only cookies         |
| SQL injection       | Parameterized queries via Supabase client            |
| XSS                 | Input sanitization (strips `< >` characters)        |
| CORS                | Configurable origin (APP_URL env var)               |
| Rate limiting       | In-memory per-IP limits on auth/checkout/contact     |
| Authorization       | Role-based (customer/admin) with server-side checks  |
| Secret exposure     | Service role key never reaches frontend              |
| Money               | Integer minor units (cents) — no floating point      |
| Stock               | Server-side validation, no client-controlled values  |

## Money Handling

All money is stored and calculated in **integer minor units** (cents):
- $699.00 → 69900 cents
- Prevents floating-point rounding errors
- `lib/money.js` handles all calculations
- Checkout endpoint recalculates ALL totals server-side

## Database Connection Management

Supabase uses HTTP-based REST API (not persistent connections), which is ideal for serverless:
- No connection pooling issues
- No cold-start connection overhead
- Each function call makes HTTP requests to Supabase's API
- Client instances are cached per Lambda container

## Caching Strategy

| Data              | Cached? | Where              |
|-------------------|---------|--------------------|
| Product catalogue | No*     | (static in js/data.js) |
| Categories        | No*     | (static in js/data.js) |
| Cart              | No      | Per-request         |
| Orders            | No      | Per-request         |
| Inventory         | No      | Per-request         |
| User session      | Yes     | JWT cookie (7 days) |

*Products and categories are already cached client-side in the immutable frontend's `js/data.js`. The backend serves fresh data for API consumers.
