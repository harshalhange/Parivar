# Database Schema — Parivar Furniture

## Overview

The database is PostgreSQL, hosted on Supabase. All money values are stored as **integer minor units (cents)** to prevent floating-point rounding errors.

## Schema Files

| File | Description |
|------|-------------|
| `database/schema/001_init.sql` | Complete schema — all tables, indexes, constraints, triggers |
| `database/seeds/001_seed.sql` | Seed data — products, categories, coupons, delivery zones, settings |

## Tables

### users
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | Auto-generated |
| email | TEXT UNIQUE | Lowercased email |
| name | TEXT | Display name |
| phone | TEXT | Optional phone |
| password_hash | TEXT | bcrypt hash (never plaintext) |
| role | user_role | `customer` or `admin` |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | Auto-updated via trigger |
| last_login_at | TIMESTAMPTZ | |

### addresses
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| user_id | UUID FK → users | |
| full_name | TEXT | |
| phone | TEXT | |
| line1 | TEXT | Street address |
| line2 | TEXT | Optional |
| city | TEXT | |
| state | TEXT | |
| postal_code | TEXT | |
| country | TEXT | Default 'India' |
| is_default | BOOLEAN | |
| created_at / updated_at | TIMESTAMPTZ | |

### categories
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| name | TEXT UNIQUE | e.g., "Living Room" |
| room | TEXT | e.g., "living" |
| image_url | TEXT | |
| created_at | TIMESTAMPTZ | |

### products
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| slug | TEXT UNIQUE | URL-friendly identifier (matches frontend product id) |
| name | TEXT | |
| description | TEXT | Full description |
| short_description | TEXT | |
| category | TEXT | e.g., "Living Room" |
| room | TEXT | e.g., "living" |
| material | TEXT | |
| fabric | TEXT | Nullable |
| badge | TEXT | "Best Seller", "New", "Sale", or null |
| price | INTEGER | Price in cents (69900 = $699.00) |
| compare_at_price | INTEGER | Old price in cents (for sale items) |
| currency | TEXT | Default 'USD' |
| availability | TEXT | "In Stock" |
| stock_quantity | INTEGER | Current stock |
| low_stock_threshold | INTEGER | Default 5 |
| featured | BOOLEAN | Show on homepage |
| rating | NUMERIC(2,1) | e.g., 4.8 |
| review_count | INTEGER | Auto-updated by trigger |
| status | product_status | `draft`, `active`, `archived` |
| features | JSONB | Array of feature strings |
| specs | JSONB | Object of spec key-values |
| colors | JSONB | Array of {name, hex} objects |
| complete_room | JSONB | Array of related product slugs |
| created_at / updated_at | TIMESTAMPTZ | |

### product_images
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| product_id | UUID FK → products | |
| image_url | TEXT | Full URL |
| sort_order | INTEGER | Display order |
| alt_text | TEXT | |
| created_at | TIMESTAMPTZ | |

### product_variants
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| product_id | UUID FK → products | |
| name | TEXT | e.g., "Color" |
| value | TEXT | e.g., "Beige" |
| price_modifier | INTEGER | In cents |
| sku | TEXT | |
| stock_quantity | INTEGER | |
| created_at | TIMESTAMPTZ | |

### inventory
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| product_id | UUID FK → products | |
| variant_id | UUID FK → product_variants | Nullable |
| available_qty | INTEGER | |
| reserved_qty | INTEGER | |
| sold_qty | INTEGER | |
| low_stock_threshold | INTEGER | |
| stock_status | stock_status | `in_stock`, `low_stock`, `out_of_stock` |
| updated_at | TIMESTAMPTZ | |

### carts
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| user_id | UUID FK → users | Nullable (guest cart) |
| session_id | TEXT | For guest carts |
| currency | TEXT | |
| subtotal | INTEGER | In cents |
| discount | INTEGER | |
| shipping | INTEGER | |
| total | INTEGER | |
| created_at / updated_at | TIMESTAMPTZ | |

### cart_items
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| cart_id | UUID FK → carts | |
| product_id | UUID FK → products | |
| variant_id | UUID FK → product_variants | |
| quantity | INTEGER | CHECK > 0 |
| unit_price | INTEGER | Server-resolved, in cents |
| created_at / updated_at | TIMESTAMPTZ | |

### wishlists
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| user_id | UUID FK → users | Nullable |
| session_id | TEXT | For guests |
| created_at | TIMESTAMPTZ | |

### wishlist_items
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| wishlist_id | UUID FK → wishlists | |
| product_id | UUID FK → products | |
| created_at | TIMESTAMPTZ | |
| | | UNIQUE(wishlist_id, product_id) |

### saved_items
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| user_id | UUID FK → users | Nullable |
| session_id | TEXT | For guests |
| product_id | UUID FK → products | |
| quantity | INTEGER | |
| variation | JSONB | |
| created_at | TIMESTAMPTZ | |

### coupons
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| code | TEXT UNIQUE | e.g., "PARIVAR10" |
| type | coupon_type | `percentage`, `fixed_amount`, `free_shipping` |
| value | INTEGER | Percentage (10) or cents (5000) |
| minimum_order | INTEGER | In cents |
| maximum_discount | INTEGER | Nullable, in cents |
| usage_limit | INTEGER | Total uses allowed |
| per_user_limit | INTEGER | Default 1 |
| start_date | TIMESTAMPTZ | Nullable |
| end_date | TIMESTAMPTZ | Nullable |
| active | BOOLEAN | |
| created_at / updated_at | TIMESTAMPTZ | |

### coupon_redemptions
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| coupon_id | UUID FK → coupons | |
| user_id | UUID FK → users | Nullable |
| session_id | TEXT | |
| order_id | UUID | |
| redeemed_at | TIMESTAMPTZ | |

### orders
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| order_number | TEXT UNIQUE | e.g., "PF12345678" |
| user_id | UUID FK → users | Nullable (guest checkout) |
| guest_email | TEXT | |
| customer_name | TEXT | |
| phone | TEXT | |
| email | TEXT | |
| subtotal | INTEGER | In cents |
| discount | INTEGER | |
| shipping | INTEGER | |
| tax | INTEGER | |
| total | INTEGER | |
| currency | TEXT | |
| coupon_code | TEXT | |
| payment_method | TEXT | "whatsapp", "card", "bank" |
| payment_status | order_payment_status | `pending`, `paid`, `failed`, `refunded`, `cod` |
| fulfillment_status | order_fulfillment_status | `confirmed`, `processing`, `shipped`, `out_for_delivery`, `delivered`, `cancelled`, `returned` |
| shipping_address | JSONB | Full address object |
| billing_address | JSONB | Nullable |
| order_note | TEXT | |
| created_at / updated_at | TIMESTAMPTZ | |

### order_items
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| order_id | UUID FK → orders | |
| product_id | UUID FK → products | SET NULL on delete |
| variant_id | UUID FK → product_variants | |
| product_name_snapshot | TEXT | Product name at time of order |
| unit_price_snapshot | INTEGER | Price at time of order (cents) |
| quantity | INTEGER | |
| line_total | INTEGER | unit_price × quantity |
| image_snapshot | TEXT | |
| created_at | TIMESTAMPTZ | |

### order_status_history
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| order_id | UUID FK → orders | |
| status | order_fulfillment_status | |
| note | TEXT | |
| created_at | TIMESTAMPTZ | |

### reviews
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| product_id | UUID FK → products | |
| user_id | UUID FK → users | |
| order_id | UUID FK → orders | |
| rating | INTEGER | CHECK 1-5 |
| title | TEXT | |
| body | TEXT | |
| verified_purchase | BOOLEAN | Server-calculated |
| status | review_status | `pending`, `approved`, `rejected` |
| created_at | TIMESTAMPTZ | |

### delivery_zones
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| postal_code | TEXT UNIQUE | |
| city | TEXT | |
| state | TEXT | |
| serviceable | BOOLEAN | |
| estimated_min_days | INTEGER | |
| estimated_max_days | INTEGER | |
| shipping_fee | INTEGER | In cents |
| created_at | TIMESTAMPTZ | |

### contact_messages
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| name | TEXT | |
| email | TEXT | |
| phone | TEXT | |
| subject | TEXT | |
| message | TEXT | |
| source | TEXT | Default 'contact_form' |
| status | contact_status | `new`, `read`, `resolved` |
| created_at | TIMESTAMPTZ | |

### analytics_events
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| event_type | TEXT | page_view, product_view, etc. |
| user_id | UUID FK → users | Nullable |
| session_id | TEXT | |
| product_id | UUID FK → products | |
| payload | JSONB | Event-specific data |
| created_at | TIMESTAMPTZ | |

### settings
| Column | Type | Description |
|--------|------|-------------|
| id | UUID PK | |
| key | TEXT UNIQUE | |
| value | JSONB | |
| updated_at | TIMESTAMPTZ | |

## Enums

- `user_role`: `customer`, `admin`
- `product_status`: `draft`, `active`, `archived`
- `stock_status`: `in_stock`, `low_stock`, `out_of_stock`
- `order_fulfillment_status`: `confirmed`, `processing`, `shipped`, `out_for_delivery`, `delivered`, `cancelled`, `returned`
- `order_payment_status`: `pending`, `paid`, `failed`, `refunded`, `cod`
- `review_status`: `pending`, `approved`, `rejected`
- `contact_status`: `new`, `read`, `resolved`
- `coupon_type`: `percentage`, `fixed_amount`, `free_shipping`

## Triggers

1. **update_updated_at()** — Auto-updates `updated_at` on row update for all tables with that column.
2. **update_product_review_stats()** — Auto-updates `rating` and `review_count` on the products table when reviews are inserted, updated (status change), or deleted.

## Seed Data

The seed file populates:
- 4 categories (Living Room, Dining Room, Bedroom, Storage)
- 8 products (mirroring `js/data.js` exactly)
- 20 product images
- 8 inventory records
- 3 coupons (PARIVAR10, WELCOME50, FREESHIP)
- 20 delivery zones (major Indian cities)
- 1 admin user (placeholder password — use `/api/auth/setup`)
- 9 settings entries
