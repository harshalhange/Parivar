-- ============================================================
-- PARIVAR FURNITURE — Seed Data
-- Mirrors the frontend product catalogue from js/data.js
-- All prices stored in minor units (cents): $699 → 69900
-- ============================================================

-- ============= CATEGORIES =============
INSERT INTO categories (name, room, image_url) VALUES
    ('Living Room', 'living', 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&q=80'),
    ('Dining Room', 'dining', 'https://images.unsplash.com/photo-1617806118233-18e1de247200?w=600&q=80'),
    ('Bedroom',     'bedroom', 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=600&q=80'),
    ('Storage',     'storage', 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=600&q=80')
ON CONFLICT DO NOTHING;

-- ============= PRODUCTS =============
-- Product 1: Wooden 3-Seater Sofa
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'wooden-3-seater-sofa',
    'Wooden 3-Seater Sofa',
    'Our 3-seater sofa is beautifully crafted from premium solid wood, designed to bring warmth, comfort, and elegance to your living space. Built with sturdy joinery and high-quality cushions for lasting comfort you can enjoy for years.',
    'Premium solid wood 3-seater sofa with high-density foam cushions.',
    'Living Room', 'living', 'Solid Oak Wood', 'Beige', 'Best Seller',
    69900, NULL, 'USD', 'In Stock', 25, 5, TRUE, 4.8, 124, 'active',
    '["Premium solid wood frame for durability","High-density foam cushions for superior comfort","Removable cushion covers for easy cleaning","Perfect for everyday use and modern living"]'::jsonb,
    '{"dimensions":"W 210 cm × D 85 cm × H 85 cm","seating":"3 People","frame":"Solid Oak Wood","cushion":"High-Density Foam","weight":"45 kg","assembly":"Minimal Assembly Required"}'::jsonb,
    '[{"name":"Beige","hex":"#E8DCC8"},{"name":"Light Grey","hex":"#C4B5A0"},{"name":"Charcoal","hex":"#6B6B6B"},{"name":"Sage","hex":"#5A7A5A"}]'::jsonb,
    '["oak-coffee-table","solid-wood-armchair","wooden-sideboard"]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 2: Solid Wood Dining Table
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'solid-wood-dining-table',
    'Solid Wood Dining Table',
    'A timeless solid wood dining table that anchors your dining space with natural beauty and lasting strength. Crafted for family gatherings and everyday meals.',
    'Timeless solid oak dining table seating 6 comfortably.',
    'Dining Room', 'dining', 'Oak Wood', NULL, NULL,
    79900, NULL, 'USD', 'In Stock', 15, 5, FALSE, 4.8, 98, 'active',
    '["Solid oak construction","Seats 6 comfortably","Scratch-resistant finish","Easy to clean surface"]'::jsonb,
    '{"dimensions":"W 180 cm × D 90 cm × H 75 cm","seating":"6 People","frame":"Solid Oak Wood","cushion":"—","weight":"52 kg","assembly":"Minimal Assembly Required"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 3: Wooden Bed Frame
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'wooden-bed-frame',
    'Wooden Bed Frame',
    'Sleep in comfort and style with our solid wood bed frame. Designed for durability and timeless elegance in your bedroom.',
    'Solid oak wood bed frame — platform design, no box spring needed.',
    'Bedroom', 'bedroom', 'Solid Oak Wood', NULL, 'Best Seller',
    59900, NULL, 'USD', 'In Stock', 20, 5, TRUE, 4.9, 177, 'active',
    '["Solid wood construction","Platform design — no box spring needed","Strong support for all mattress types","Natural wood finish"]'::jsonb,
    '{"dimensions":"W 160 cm × D 200 cm × H 100 cm","seating":"Queen Size","frame":"Solid Oak Wood","cushion":"—","weight":"48 kg","assembly":"Required"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 4: Wooden Sideboard
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'wooden-sideboard',
    'Wooden Sideboard',
    'Elegant storage solution with ample space for dining essentials or living room display. Handcrafted solid wood sideboard.',
    'Handcrafted solid wood sideboard with soft-close hinges.',
    'Storage', 'storage', 'Natural Oak', NULL, NULL,
    49900, NULL, 'USD', 'In Stock', 12, 5, FALSE, 4.8, 82, 'active',
    '["Multiple storage compartments","Solid wood doors and drawers","Soft-close hinges","Beautiful natural grain"]'::jsonb,
    '{"dimensions":"W 150 cm × D 45 cm × H 80 cm","seating":"—","frame":"Natural Oak","cushion":"—","weight":"38 kg","assembly":"Minimal"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 5: Solid Wood Armchair
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'solid-wood-armchair',
    'Solid Wood Armchair',
    'A cozy solid wood armchair perfect for reading corners or accent seating. Comfortable and stylish.',
    'Cozy oak wood armchair with high-density cushion.',
    'Living Room', 'living', 'Oak Wood', 'Beige', NULL,
    34900, NULL, 'USD', 'In Stock', 30, 5, FALSE, 4.8, 64, 'active',
    '["Ergonomic design","High-density cushion","Solid wood frame","Easy to move"]'::jsonb,
    '{"dimensions":"W 70 cm × D 75 cm × H 85 cm","seating":"1 Person","frame":"Oak Wood","cushion":"High-Density Foam","weight":"18 kg","assembly":"None"}'::jsonb,
    '[{"name":"Beige","hex":"#E8DCC8"}]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 6: Oak Coffee Table
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'oak-coffee-table',
    'Oak Coffee Table',
    'A beautiful oak coffee table with clean lines and natural warmth. Perfect centerpiece for your living room.',
    'Solid oak coffee table with lower storage shelf.',
    'Living Room', 'living', 'Oak Wood', NULL, 'New',
    29900, NULL, 'USD', 'In Stock', 35, 5, FALSE, 4.7, 86, 'active',
    '["Solid oak top","Lower shelf for storage","Sturdy legs","Easy to clean"]'::jsonb,
    '{"dimensions":"W 110 cm × D 60 cm × H 45 cm","seating":"—","frame":"Oak Wood","cushion":"—","weight":"22 kg","assembly":"Minimal"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 7: Wooden TV Unit
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'wooden-tv-unit',
    'Wooden TV Unit',
    'Sleek wooden TV unit with cable management and storage for media devices. Modern and functional.',
    'Sleek TV unit with cable management and media storage.',
    'Storage', 'storage', 'Natural Oak', NULL, NULL,
    39900, NULL, 'USD', 'In Stock', 18, 5, FALSE, 4.7, 53, 'active',
    '["Cable management system","Open and closed storage","Solid wood construction","Supports large TVs"]'::jsonb,
    '{"dimensions":"W 160 cm × D 40 cm × H 50 cm","seating":"—","frame":"Natural Oak","cushion":"—","weight":"30 kg","assembly":"Required"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- Product 8: Sheesham Bookshelf
INSERT INTO products (slug, name, description, short_description, category, room, material, fabric, badge, price, compare_at_price, currency, availability, stock_quantity, low_stock_threshold, featured, rating, review_count, status, features, specs, colors, complete_room)
VALUES (
    'sheesham-bookshelf',
    'Sheesham Bookshelf',
    'Tall solid Sheesham bookshelf with five spacious shelves. Perfect for books, decor and display.',
    'Tall solid Sheesham bookshelf with five adjustable shelves.',
    'Storage', 'storage', 'Sheesham Wood', NULL, 'Sale',
    44900, 52900, 'USD', 'In Stock', 10, 5, FALSE, 4.6, 41, 'active',
    '["Solid Sheesham wood","Five adjustable shelves","Anti-tip hardware included","Natural grain finish"]'::jsonb,
    '{"dimensions":"W 90 cm × D 35 cm × H 180 cm","seating":"—","frame":"Sheesham Wood","cushion":"—","weight":"42 kg","assembly":"Required"}'::jsonb,
    '[]'::jsonb,
    '[]'::jsonb
) ON CONFLICT (slug) DO NOTHING;

-- ============= PRODUCT IMAGES =============
INSERT INTO product_images (product_id, image_url, sort_order, alt_text)
SELECT p.id, img.url, img.idx, p.name FROM products p
JOIN (VALUES
    ('wooden-3-seater-sofa', 0, 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=80'),
    ('wooden-3-seater-sofa', 1, 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=900&q=80'),
    ('wooden-3-seater-sofa', 2, 'https://images.unsplash.com/photo-1567016432779-094069958ea5?w=900&q=80'),
    ('wooden-3-seater-sofa', 3, 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=900&q=80'),
    ('solid-wood-dining-table', 0, 'https://images.unsplash.com/photo-1617806118233-18e1de247200?w=900&q=80'),
    ('solid-wood-dining-table', 1, 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?w=900&q=80'),
    ('solid-wood-dining-table', 2, 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80'),
    ('wooden-bed-frame', 0, 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=900&q=80'),
    ('wooden-bed-frame', 1, 'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=900&q=80'),
    ('wooden-bed-frame', 2, 'https://images.unsplash.com/photo-1588046130717-6eb63bb3217d?w=900&q=80'),
    ('wooden-sideboard', 0, 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80'),
    ('wooden-sideboard', 1, 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=80'),
    ('solid-wood-armchair', 0, 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=900&q=80'),
    ('solid-wood-armchair', 1, 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=900&q=80'),
    ('oak-coffee-table', 0, 'https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?w=900&q=80'),
    ('oak-coffee-table', 1, 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=900&q=80'),
    ('wooden-tv-unit', 0, 'https://images.unsplash.com/photo-1615873968403-89e068629265?w=900&q=80'),
    ('wooden-tv-unit', 1, 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80'),
    ('sheesham-bookshelf', 0, 'https://images.unsplash.com/photo-1594620302200-9a762244a156?w=900&q=80'),
    ('sheesham-bookshelf', 1, 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=900&q=80')
) AS img(slug, idx, url) ON img.slug = p.slug
ON CONFLICT DO NOTHING;

-- ============= INVENTORY =============
INSERT INTO inventory (product_id, variant_id, available_qty, reserved_qty, sold_qty, low_stock_threshold, stock_status)
SELECT id, NULL, stock_quantity, 0, 0, low_stock_threshold,
    CASE WHEN stock_quantity = 0 THEN 'out_of_stock'::stock_status
         WHEN stock_quantity <= low_stock_threshold THEN 'low_stock'::stock_status
         ELSE 'in_stock'::stock_status END
FROM products
ON CONFLICT DO NOTHING;

-- ============= COUPONS =============
INSERT INTO coupons (code, type, value, minimum_order, maximum_discount, usage_limit, per_user_limit, start_date, end_date, active)
VALUES
    ('PARIVAR10', 'percentage',  10, 0,    NULL, 1000, 1, NULL, NULL, TRUE),
    ('WELCOME50', 'fixed_amount', 5000, 0,  NULL, 1000, 1, NULL, NULL, TRUE),
    ('FREESHIP',  'free_shipping', 0, 0,   NULL, 1000, 1, NULL, NULL, TRUE)
ON CONFLICT (code) DO NOTHING;

-- ============= DELIVERY ZONES =============
INSERT INTO delivery_zones (postal_code, city, state, serviceable, estimated_min_days, estimated_max_days, shipping_fee)
VALUES
    ('110001', 'New Delhi',    'Delhi',           TRUE, 3, 7, 4900),
    ('400001', 'Mumbai',       'Maharashtra',     TRUE, 3, 7, 4900),
    ('560001', 'Bengaluru',    'Karnataka',       TRUE, 4, 8, 4900),
    ('600001', 'Chennai',      'Tamil Nadu',      TRUE, 4, 8, 4900),
    ('700001', 'Kolkata',      'West Bengal',     TRUE, 4, 8, 4900),
    ('500001', 'Hyderabad',    'Telangana',       TRUE, 4, 8, 4900),
    ('411001', 'Pune',         'Maharashtra',     TRUE, 3, 7, 4900),
    ('380001', 'Ahmedabad',    'Gujarat',         TRUE, 4, 8, 4900),
    ('302001', 'Jaipur',       'Rajasthan',       TRUE, 4, 8, 4900),
    ('226001', 'Lucknow',      'Uttar Pradesh',   TRUE, 5, 9, 4900),
    ('462001', 'Bhopal',       'Madhya Pradesh',  TRUE, 5, 9, 4900),
    ('682001', 'Kochi',        'Kerala',          TRUE, 5, 9, 4900),
    ('530001', 'Visakhapatnam','Andhra Pradesh',  TRUE, 5, 9, 4900),
    ('160001', 'Chandigarh',   'Chandigarh',      TRUE, 4, 8, 4900),
    ('143001', 'Amritsar',     'Punjab',          TRUE, 5, 9, 4900),
    ('781001', 'Guwahati',     'Assam',           TRUE, 6, 10, 5900),
    ('751001', 'Bhubaneswar',  'Odisha',          TRUE, 5, 9, 4900),
    ('208001', 'Kanpur',       'Uttar Pradesh',   TRUE, 5, 9, 4900),
    ('695001', 'Thiruvananthapuram', 'Kerala',    TRUE, 6, 10, 5900),
    ('712001', 'Howrah',       'West Bengal',     TRUE, 4, 8, 4900)
ON CONFLICT (postal_code) DO NOTHING;

-- ============= ADMIN USER =============
-- Default admin: admin@parivarfurniture.com / Admin@Parivar2026
-- Password is hashed with bcrypt in the application layer on first run.
-- This is a placeholder; the /api/auth/setup endpoint will create the real admin.
INSERT INTO users (email, name, phone, role, password_hash)
VALUES ('admin@parivarfurniture.com', 'Parivar Admin', '+919876543210', 'admin', '$2a$10$PLACEHOLDER_RUN_SETUP_ENDPOINT')
ON CONFLICT (email) DO NOTHING;

-- ============= SETTINGS =============
INSERT INTO settings (key, value) VALUES
    ('whatsapp_number',  '"919876543210"'::jsonb),
    ('currency',         '"USD"'::jsonb),
    ('shipping_threshold', '29900'::jsonb),
    ('shipping_fee',      '4900'::jsonb),
    ('tax_rate',         '0.08'::jsonb),
    ('free_shipping_enabled', 'true'::jsonb),
    ('store_name',       '"Parivar Furniture"'::jsonb),
    ('store_email',       '"hello@parivarfurniture.com"'::jsonb),
    ('store_phone',       '"+91 98765 43210"'::jsonb)
ON CONFLICT (key) DO NOTHING;
