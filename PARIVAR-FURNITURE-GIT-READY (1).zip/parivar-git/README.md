# Parivar Furniture — Client-Ready Storefront

Static multi-page furniture e-commerce site (HTML / CSS / JS).

## Deploy to Netlify

1. Zip the **contents** of this folder (or connect the folder to Git).
2. Drag-and-drop the folder to [Netlify Drop](https://app.netlify.com/drop), **or**  
   `netlify deploy --prod --dir=.`
3. `_redirects` enables clean URLs: `/shop`, `/cart`, `/product?id=…`, etc.

## Local preview

Open `index.html` in a browser, or:

```bash
npx serve .
```

## Customize for client

| Item | File / location |
|------|------------------|
| WhatsApp number | `js/data.js` → `WHATSAPP_NUMBER` |
| Products / prices | `js/data.js` → `PRODUCTS` |
| Promo codes | `js/cart.js` → `PROMO_CODES` |
| Brand colors | `css/styles.css` → `:root` |
| Logo | Header in `js/common.js` |

### Demo promo codes

- `PARIVAR10` — 10% off  
- `WELCOME50` — $50 off  
- `FREESHIP` — free shipping  

## Pages

- Home, Shop, Product, Cart, Checkout, Order Success, Order Tracking  
- Wishlist, Account, About, Contact  

## Notes

- Cart / wishlist / orders use `localStorage` (browser-only).  
- PIN checker and reviews are **demo** estimates/samples.  
- Replace Unsplash images with client photography before go-live.
