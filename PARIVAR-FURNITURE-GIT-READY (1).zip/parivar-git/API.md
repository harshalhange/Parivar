# API Documentation — Parivar Furniture

## Base URL

```
Production:  https://your-site.netlify.app/.netlify/functions
Local dev:   http://localhost:8888/.netlify/functions
```

All endpoints return JSON in a consistent format:

### Success Response
```json
{ "success": true, "data": { ... } }
```

### Error Response
```json
{ "success": false, "error": { "code": "ERROR_CODE", "message": "Human-readable message" } }
```

### Authentication
Authenticated endpoints expect a `parivar_session` cookie (set on signin/signup) or an `Authorization: Bearer <token>` header.

---

## Products

### GET /api/products
List all active products.

**Query Parameters:**
| Param      | Type   | Description                |
|------------|--------|----------------------------|
| category   | string | Filter by category name    |
| room       | string | Filter by room (living, dining, bedroom, storage) |
| q          | string | Search query               |
| featured   | string | Set to "true" for featured only |

**Response:**
```json
{
  "success": true,
  "data": {
    "products": [
      {
        "id": "wooden-3-seater-sofa",
        "name": "Wooden 3-Seater Sofa",
        "category": "Living Room",
        "room": "living",
        "price": 699,
        "oldPrice": null,
        "rating": 4.8,
        "reviews": 124,
        "material": "Solid Oak Wood",
        "images": ["https://..."],
        "features": ["..."],
        "specs": { "dimensions": "..." },
        "colors": [{ "name": "Beige", "hex": "#E8DCC8" }],
        "completeRoom": ["oak-coffee-table"]
      }
    ],
    "total": 8
  }
}
```

### GET /api/products/:id
Get a single product by slug.

**Response:** `{ "success": true, "data": { "product": { ... } } }`

### GET /api/categories
List all categories.

---

## Cart

### GET /api/cart
Get the current user's or session's cart.

### POST /api/cart
Add an item to the cart.

**Body:**
```json
{ "productId": "wooden-3-seater-sofa", "quantity": 1 }
```

### PATCH /api/cart
Update item quantity.

**Body:**
```json
{ "itemId": "uuid", "quantity": 2 }
```

### DELETE /api/cart
Clear the entire cart.

### DELETE /api/cart/items/:id
Remove a specific item from the cart.

---

## Wishlist

### GET /api/wishlist
Get wishlist product IDs.

### POST /api/wishlist
Add a product to wishlist.

**Body:** `{ "productId": "wooden-3-seater-sofa" }`

### DELETE /api/wishlist?productId=x
Remove a product from wishlist.

---

## Saved Items (Save for Later)

### GET /api/saved
List saved items.

### POST /api/saved
Save an item for later.

**Body:** `{ "productId": "wooden-3-seater-sofa", "quantity": 1 }`

### DELETE /api/saved/:id
Remove a saved item.

---

## Coupons

### POST /api/coupons/validate
Validate a coupon code (server-authoritative).

**Body:**
```json
{ "code": "PARIVAR10", "subtotalCents": 69900 }
```

**Response:**
```json
{
  "success": true,
  "data": {
    "valid": true,
    "coupon": {
      "code": "PARIVAR10",
      "type": "percentage",
      "value": 10,
      "discountCents": 6990,
      "discount": 69.90,
      "freeShipping": false
    }
  }
}
```

---

## Checkout

### POST /api/checkout
Create an order (server-authoritative).

**Body:**
```json
{
  "fullName": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "address": "123 Main St",
  "city": "Mumbai",
  "state": "Maharashtra",
  "zip": "400001",
  "country": "India",
  "note": "Leave at front door",
  "paymentMethod": "whatsapp",
  "items": [
    { "productId": "wooden-3-seater-sofa", "quantity": 1 }
  ],
  "couponCode": "PARIVAR10"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "order": {
      "id": "uuid",
      "orderNumber": "PF12345678",
      "subtotal": 699.00,
      "discount": 69.90,
      "shipping": 0,
      "tax": 50.33,
      "total": 679.43,
      "items": [...],
      "shippingAddress": { ... },
      "status": "confirmed"
    },
    "whatsappUrl": "https://wa.me/919876543210?text=..."
  }
}
```

The backend validates:
- Product existence and active status
- Stock availability per item
- Coupon validity (date, usage limits, minimum order)
- Calculates ALL prices server-side (never trusts client totals)
- Creates order items with price snapshots
- Decrements inventory atomically
- Records coupon redemption

---

## Orders

### GET /api/orders
List the authenticated user's orders.

### GET /api/orders/:orderNumber
Get order detail (requires ownership or admin).

### GET /api/orders/:orderNumber/tracking
Get order tracking timeline.

**Response:**
```json
{
  "success": true,
  "data": {
    "tracking": {
      "orderNumber": "PF12345678",
      "status": "confirmed",
      "total": 679.43,
      "statusIndex": 0,
      "timeline": [
        { "status": "confirmed", "label": "Confirmed", "completed": true },
        { "status": "processing", "label": "Processing", "completed": false },
        ...
      ]
    }
  }
}
```

---

## Reviews

### GET /api/reviews?productId=wooden-3-seater-sofa
List approved reviews for a product.

### POST /api/reviews
Submit a review (requires authentication).

**Body:**
```json
{
  "productId": "wooden-3-seater-sofa",
  "rating": 5,
  "title": "Great sofa!",
  "body": "Really comfortable and well-built."
}
```

Reviews are submitted with `status: pending` and require admin approval. Verified purchase is calculated server-side from order history.

---

## Delivery

### POST /api/delivery/check
Check delivery serviceability for a postal code.

**Body:** `{ "postalCode": "400001" }`

**Response:**
```json
{
  "success": true,
  "data": {
    "serviceable": true,
    "estimatedDelivery": { "minDays": 3, "maxDays": 7 },
    "shippingFee": 4900,
    "shippingFeeDisplay": "$49.00",
    "city": "Mumbai",
    "state": "Maharashtra"
  }
}
```

---

## Contact

### POST /api/contact
Submit a contact/enquiry message.

**Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "subject": "Question about delivery",
  "message": "When will my order arrive?"
}
```

---

## Authentication

### POST /api/auth/signup
Register a new customer account.

**Body:** `{ "email": "...", "password": "...", "name": "..." }`

### POST /api/auth/signin
Sign in.

**Body:** `{ "email": "...", "password": "..." }`

### POST /api/auth/signout
Sign out (clears session cookie).

### GET /api/auth/me
Get current authenticated user.

### POST /api/auth/setup
Create the admin user (first-run only — fails if admin already exists).

**Body:** `{ "email": "...", "password": "...", "name": "Admin" }`

---

## Account

### GET /api/account
Get account details (requires auth).

### PATCH /api/account
Update account (name, phone).

### GET /api/account/addresses
List saved addresses.

### POST /api/account/addresses
Create a new address.

**Body:**
```json
{
  "fullName": "John Doe",
  "phone": "9876543210",
  "line1": "123 Main St",
  "line2": "Apt 4B",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postalCode": "400001",
  "country": "India",
  "isDefault": true
}
```

### PATCH /api/account/addresses/:id
Update an address.

### DELETE /api/account/addresses/:id
Delete an address.

---

## Analytics

### POST /api/analytics
Record an analytics event.

**Body:** `{ "eventType": "page_view", "productId": "wooden-3-seater-sofa" }`

Valid event types: `page_view`, `product_view`, `add_to_cart`, `wishlist_add`, `checkout_start`, `purchase`, `search`, `coupon_apply`

### GET /api/analytics
List recent events (admin only).

---

## Admin

All admin endpoints require an authenticated admin user.

### GET /api/admin/dashboard
Get dashboard statistics (revenue, orders, products, customers, etc.)

### Products
- `GET /api/admin/products` — list all (incl. draft/archived)
- `POST /api/admin/products` — create
- `PATCH /api/admin/products/:id` — update
- `DELETE /api/admin/products/:id` — delete

### Orders
- `GET /api/admin/orders` — list all orders
- `PATCH /api/admin/orders/:id` — update status

### Coupons
- `GET /api/admin/coupons` — list
- `POST /api/admin/coupons` — create
- `PATCH /api/admin/coupons/:id` — update

### Reviews
- `GET /api/admin/reviews` — list all reviews
- `PATCH /api/admin/reviews/:id` — approve/reject

### Customers
- `GET /api/admin/customers` — list

### Contact Messages
- `GET /api/admin/contact` — list
- `PATCH /api/admin/contact/:id` — update status

### Inventory
- `GET /api/admin/inventory` — list
- `PATCH /api/admin/inventory/:id` — update stock

---

## Database Initialization

### POST /api/db-init
Returns information about database SQL files. Since Supabase REST API doesn't support multi-statement SQL, the SQL files must be run in the Supabase SQL Editor.
