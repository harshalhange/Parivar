/**
 * Cart API — GET/POST/PATCH/DELETE
 * GET    /api/cart              — get cart for user/session
 * POST   /api/cart              — add item to cart
 * PATCH  /api/cart              — update item quantity
 * DELETE /api/cart              — clear cart
 * DELETE /api/cart/items/:id    — remove item
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { getAuthUser, getOrCreateSessionId, setGuestSessionCookie } = require('./lib/auth');

async function getCart(db, userId, sessionId) {
  let query = db.from('carts').select('*, cart_items(*, products!inner(slug, name, price))');
  if (userId) query = query.eq('user_id', userId);
  else query = query.eq('session_id', sessionId);
  query = query.single();

  const { data: cart, error } = await query;
  if (error || !cart) {
    // Create new cart
    const cartData = { user_id: userId, session_id: userId ? null : sessionId, currency: 'USD' };
    const { data: newCart, error: createErr } = await db.from('carts').insert(cartData).select().single();
    if (createErr) throw createErr;
    return { ...newCart, cart_items: [] };
  }
  return cart;
}

async function recalcCart(db, cartId) {
  const { data: items } = await db.from('cart_items').select('unit_price, quantity').eq('cart_id', cartId);
  const subtotal = (items || []).reduce((s, i) => s + i.unit_price * i.quantity, 0);
  await db.from('carts').update({ subtotal, total: subtotal }).eq('id', cartId);
}

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) {
    return success({ cart: { items: [] }, message: 'Database not configured' });
  }

  try {
    const db = getClient();
    const sessionId = getOrCreateSessionId(event);
    const user = await getAuthUser(event, db);
    const userId = user?.id || null;

    // GET cart
    if (event.httpMethod === 'GET') {
      const cart = await getCart(db, userId, sessionId);
      return success({ cart: formatCart(cart) }, 200, { 'Set-Cookie': setGuestSessionCookie(sessionId) });
    }

    // POST add item
    if (event.httpMethod === 'POST') {
      const body = parseBody(event);
      if (!body || !body.productId || !body.quantity) {
        return badRequest('productId and quantity are required');
      }
      const cart = await getCart(db, userId, sessionId);

      // Resolve product price server-side
      const { data: product } = await db.from('products').select('id, slug, name, price, stock_quantity').eq('slug', body.productId).eq('status', 'active').single();
      if (!product) return badRequest('Product not found');

      // Check stock
      if (product.stock_quantity < body.quantity) {
        return badRequest('Insufficient stock for ' + product.name);
      }

      // Check if item already in cart
      const { data: existing } = await db.from('cart_items').select('*').eq('cart_id', cart.id).eq('product_id', product.id).single();
      if (existing) {
        await db.from('cart_items').update({ quantity: existing.quantity + body.quantity }).eq('id', existing.id);
      } else {
        await db.from('cart_items').insert({
          cart_id: cart.id,
          product_id: product.id,
          quantity: body.quantity,
          unit_price: product.price
        });
      }
      await recalcCart(db, cart.id);
      const updated = await getCart(db, userId, sessionId);
      return success({ cart: formatCart(updated), message: 'Item added to cart' });
    }

    // PATCH update quantity
    if (event.httpMethod === 'PATCH') {
      const body = parseBody(event);
      if (!body || !body.itemId || !body.quantity) {
        return badRequest('itemId and quantity are required');
      }
      const cart = await getCart(db, userId, sessionId);
      const { data: item } = await db.from('cart_items').select('*').eq('id', body.itemId).eq('cart_id', cart.id).single();
      if (!item) return badRequest('Cart item not found');

      if (body.quantity <= 0) {
        await db.from('cart_items').delete().eq('id', body.itemId);
      } else {
        await db.from('cart_items').update({ quantity: body.quantity }).eq('id', body.itemId);
      }
      await recalcCart(db, cart.id);
      const updated = await getCart(db, userId, sessionId);
      return success({ cart: formatCart(updated) });
    }

    // DELETE clear cart or remove item
    if (event.httpMethod === 'DELETE') {
      const cart = await getCart(db, userId, sessionId);
      const pathParts = (event.path || '').split('/');
      const itemId = pathParts[pathParts.length - 1];

      if (itemId && itemId !== 'cart') {
        await db.from('cart_items').delete().eq('id', itemId).eq('cart_id', cart.id);
      } else {
        await db.from('cart_items').delete().eq('cart_id', cart.id);
      }
      await recalcCart(db, cart.id);
      const updated = await getCart(db, userId, sessionId);
      return success({ cart: formatCart(updated) });
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('cart error:', err.message);
    return serverError('Cart operation failed');
  }
}

function formatCart(cart) {
  const items = (cart.cart_items || []).map(i => ({
    id: i.id,
    productId: i.products?.slug,
    name: i.products?.name,
    price: (i.products?.price || i.unit_price) / 100,
    quantity: i.quantity,
    unitPriceCents: i.unit_price
  }));
  return {
    id: cart.id,
    items,
    subtotal: cart.subtotal / 100,
    subtotalCents: cart.subtotal,
    total: cart.total / 100,
    totalCents: cart.total
  };
}

exports.handler = safeHandler(handler);
