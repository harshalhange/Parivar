/**
 * Save for Later API — GET/POST/DELETE
 * GET    /api/saved              — list saved items
 * POST   /api/saved              — save item for later
 * DELETE /api/saved/:id          — remove saved item
 * POST   /api/saved/:id/move     — move saved item to cart
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { getAuthUser, getOrCreateSessionId, setGuestSessionCookie } = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) {
    return success({ savedItems: [] });
  }

  try {
    const db = getClient();
    const sessionId = getOrCreateSessionId(event);
    const user = await getAuthUser(event, db);
    const userId = user?.id || null;

    let query = db.from('saved_items').select('*, products!inner(slug, name, price)').order('created_at', { ascending: false });
    if (userId) query = query.eq('user_id', userId);
    else query = query.eq('session_id', sessionId);

    if (event.httpMethod === 'GET') {
      const { data, error } = await query;
      if (error) throw error;
      const items = (data || []).map(i => ({
        id: i.id,
        productId: i.products?.slug,
        name: i.products?.name,
        price: (i.products?.price || 0) / 100,
        quantity: i.quantity,
        variation: i.variation
      }));
      return success({ savedItems: items }, 200, { 'Set-Cookie': setGuestSessionCookie(sessionId) });
    }

    if (event.httpMethod === 'POST') {
      const body = parseBody(event);
      if (!body || !body.productId) return badRequest('productId is required');
      const { data: product } = await db.from('products').select('id').eq('slug', body.productId).single();
      if (!product) return badRequest('Product not found');

      const payload = {
        user_id: userId,
        session_id: userId ? null : sessionId,
        product_id: product.id,
        quantity: body.quantity || 1,
        variation: body.variation || {}
      };
      const { data: saved, error: saveErr } = await db.from('saved_items').insert(payload).select().single();
      if (saveErr) throw saveErr;
      return success({ message: 'Item saved for later', savedItemId: saved.id });
    }

    if (event.httpMethod === 'DELETE') {
      const pathParts = (event.path || '').split('/');
      const itemId = pathParts[pathParts.length - 1];
      if (!itemId) return badRequest('Item ID is required');
      await db.from('saved_items').delete().eq('id', itemId);
      return success({ message: 'Saved item removed' });
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('saved error:', err.message);
    return serverError('Saved items operation failed');
  }
}

exports.handler = safeHandler(handler);
