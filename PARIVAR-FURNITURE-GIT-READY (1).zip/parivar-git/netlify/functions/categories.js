/**
 * GET /api/categories — List all categories
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, serverError, handleOptions } = require('./lib/responses');
const { safeHandler } = require('./lib/security');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isConfigured()) {
    return success({ categories: [] });
  }

  try {
    const db = getClient();
    const { data: categories, error } = await db.from('categories').select('*').order('name', { ascending: true });
    if (error) throw error;

    return success({
      categories: (categories || []).map(c => ({
        id: c.room,
        name: c.name,
        room: c.room,
        image: c.image_url
      }))
    });
  } catch (err) {
    console.error('categories error:', err.message);
    return serverError('Failed to fetch categories');
  }
}

exports.handler = safeHandler(handler);
