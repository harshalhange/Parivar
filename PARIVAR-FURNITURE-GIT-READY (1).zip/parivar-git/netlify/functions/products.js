/**
 * GET /api/products — List all products (frontend-compatible format)
 * GET /api/products?category=Living Room
 * GET /api/products?room=living
 * GET /api/products?q=sofa
 */
const { getClient, isConfigured } = require('./lib/db');
const { dbProductToFrontend, getProductImages } = require('./lib/products');
const { success, serverError, handleOptions } = require('./lib/responses');
const { safeHandler } = require('./lib/security');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isConfigured()) {
    return success({ products: [], message: 'Database not configured. See README for setup.' });
  }

  try {
    const db = getClient();
    const params = event.queryStringParameters || {};
    let query = db.from('products').select('*').eq('status', 'active').order('created_at', { ascending: true });

    if (params.category) {
      query = query.eq('category', params.category);
    }
    if (params.room) {
      query = query.eq('room', params.room);
    }
    if (params.q) {
      query = query.or(`name.ilike.%${params.q}%,description.ilike.%${params.q}%,category.ilike.%${params.q}%`);
    }
    if (params.featured === 'true') {
      query = query.eq('featured', true);
    }

    const { data: products, error } = await query;
    if (error) throw error;

    // Fetch images for all products
    const result = [];
    for (const p of products) {
      const images = await getProductImages(db, p.id);
      result.push(dbProductToFrontend(p, images));
    }

    return success({ products: result, total: result.length });
  } catch (err) {
    console.error('products error:', err.message);
    return serverError('Failed to fetch products');
  }
}

exports.handler = safeHandler(handler);
