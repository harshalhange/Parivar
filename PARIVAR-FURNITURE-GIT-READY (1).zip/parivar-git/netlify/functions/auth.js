/**
 * Authentication API
 * POST /api/auth/signup   — register a new customer
 * POST /api/auth/signin   — sign in
 * POST /api/auth/signout  — sign out
 * POST /api/auth/setup     — create admin user (first-run only)
 * GET  /api/auth/me        — get current user
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, validationError, serverError, unauthorized, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody, checkRateLimit, getClientIp } = require('./lib/security');
const { validateEmail, validatePassword, sanitizeString } = require('./lib/validation');
const {
  hashPassword, verifyPassword, createToken, verifyToken,
  extractToken, getAuthUser, setSessionCookie, clearSessionCookie
} = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (!isConfigured()) {
    return success({ user: null, message: 'Auth not configured — running in demo mode' });
  }

  try {
    const db = getClient();
    const path = event.path || '';
    const action = path.split('/').pop() || '';
    const method = event.httpMethod;

    // ---- SETUP (first-run admin creation) ----
    if (action === 'setup' && method === 'POST') {
      const body = parseBody(event);
      if (!body || !body.email || !body.password) return badRequest('Email and password required');
      // Only allow if no admin exists yet
      const { data: existingAdmin } = await db.from('users').select('id').eq('role', 'admin').limit(1);
      if (existingAdmin && existingAdmin.length > 0) {
        return badRequest('Admin user already exists. Use signin instead.');
      }
      const hash = await hashPassword(body.password);
      const { data: admin, error } = await db.from('users').upsert({
        email: body.email.toLowerCase(),
        name: body.name || 'Admin',
        phone: body.phone || null,
        role: 'admin',
        password_hash: hash,
        last_login_at: new Date().toISOString()
      }, { onConflict: 'email' }).select().single();
      if (error) throw error;
      const token = createToken({ sub: admin.id, email: admin.email, role: 'admin' });
      return success({ user: { id: admin.id, email: admin.email, name: admin.name, role: 'admin' }, token }, 201, { 'Set-Cookie': setSessionCookie(token) });
    }

    // ---- SIGNUP ----
    if (action === 'signup' && method === 'POST') {
      const rl = checkRateLimit(getClientIp(event), 'auth');
      if (!rl.allowed) return { statusCode: 429, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many attempts. Try later.' } }) };

      const body = parseBody(event);
      if (!body) return badRequest('Invalid request body');
      const emailErr = validateEmail(body.email);
      const passErr = validatePassword(body.password);
      const errors = {};
      if (emailErr) errors.email = emailErr;
      if (passErr) errors.password = passErr;
      if (!body.name || !body.name.trim()) errors.name = 'Name is required';
      if (Object.keys(errors).length > 0) return validationError(errors);

      // Check if email already exists
      const { data: existing } = await db.from('users').select('id').eq('email', body.email.toLowerCase()).limit(1);
      if (existing && existing.length > 0) return badRequest('An account with this email already exists');

      const hash = await hashPassword(body.password);
      const { data: user, error } = await db.from('users').insert({
        email: body.email.toLowerCase(),
        name: sanitizeString(body.name),
        phone: body.phone ? sanitizeString(body.phone) : null,
        role: 'customer',
        password_hash: hash,
        last_login_at: new Date().toISOString()
      }).select().single();
      if (error) throw error;

      const token = createToken({ sub: user.id, email: user.email, role: user.role });
      return success({ user: { id: user.id, email: user.email, name: user.name, role: user.role }, token }, 201, { 'Set-Cookie': setSessionCookie(token) });
    }

    // ---- SIGNIN ----
    if (action === 'signin' && method === 'POST') {
      const rl = checkRateLimit(getClientIp(event), 'auth');
      if (!rl.allowed) return { statusCode: 429, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many attempts. Try later.' } }) };

      const body = parseBody(event);
      if (!body || !body.email || !body.password) return badRequest('Email and password are required');

      const { data: user, error } = await db.from('users')
        .select('*')
        .eq('email', body.email.toLowerCase())
        .single();
      if (error || !user) return unauthorized('Invalid email or password');

      const valid = await verifyPassword(body.password, user.password_hash);
      if (!valid) return unauthorized('Invalid email or password');

      await db.from('users').update({ last_login_at: new Date().toISOString() }).eq('id', user.id);
      const token = createToken({ sub: user.id, email: user.email, role: user.role });
      return success({ user: { id: user.id, email: user.email, name: user.name, role: user.role }, token }, 200, { 'Set-Cookie': setSessionCookie(token) });
    }

    // ---- SIGNOUT ----
    if (action === 'signout' && method === 'POST') {
      return success({ message: 'Signed out' }, 200, { 'Set-Cookie': clearSessionCookie() });
    }

    // ---- ME (get current user) ----
    if (action === 'me' && method === 'GET') {
      const user = await getAuthUser(event, db);
      if (!user) return success({ user: null });
      return success({ user: { id: user.id, email: user.email, name: user.name, role: user.role, phone: user.phone } });
    }

    return { statusCode: 404, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'NOT_FOUND', message: 'Auth endpoint not found' } }) };
  } catch (err) {
    console.error('auth error:', err.message);
    return serverError('Authentication operation failed');
  }
}

exports.handler = safeHandler(handler);
