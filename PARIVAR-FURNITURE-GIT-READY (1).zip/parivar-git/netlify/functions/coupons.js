/**
 * Coupon Validation API
 * POST /api/coupons/validate — validate a coupon code (server-authoritative)
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { calculateDiscount } = require('./lib/money');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) {
    // Fallback to hardcoded demo coupons matching frontend PROMO_CODES
    const body = parseBody(event) || {};
    const DEMO = {
      'PARIVAR10': { type: 'percentage', value: 10, label: '10% off' },
      'WELCOME50': { type: 'fixed_amount', value: 5000, label: '$50 off' },
      'FREESHIP': { type: 'free_shipping', value: 0, label: 'Free shipping' }
    };
    const code = (body.code || '').trim().toUpperCase();
    const coupon = DEMO[code];
    if (!coupon) return success({ valid: false, message: 'That code couldn\'t be applied.' });
    return success({ valid: true, coupon: { code, ...coupon }, message: coupon.label + ' applied' });
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  try {
    const db = getClient();
    const body = parseBody(event);
    if (!body || !body.code) return badRequest('Coupon code is required');
    if (!body.subtotalCents && !body.subtotal) return badRequest('Subtotal is required');

    const code = (body.code || '').trim().toUpperCase();
    const subtotal = body.subtotalCents || Math.round(body.subtotal * 100);

    const { data: coupon, error } = await db.from('coupons')
      .select('*')
      .eq('code', code)
      .eq('active', true)
      .single();

    if (error || !coupon) {
      return success({ valid: false, message: 'That code couldn\'t be applied.' });
    }

    // Check date validity
    const now = new Date();
    if (coupon.start_date && new Date(coupon.start_date) > now) {
      return success({ valid: false, message: 'This coupon is not yet active.' });
    }
    if (coupon.end_date && new Date(coupon.end_date) < now) {
      return success({ valid: false, message: 'This coupon has expired.' });
    }

    // Check minimum order
    if (coupon.minimum_order && subtotal < coupon.minimum_order) {
      return success({ valid: false, message: `Minimum order of $${(coupon.minimum_order / 100).toFixed(2)} required.` });
    }

    // Check usage limit
    if (coupon.usage_limit) {
      const { count } = await db.from('coupon_redemptions')
        .select('*', { count: 'exact', head: true })
        .eq('coupon_id', coupon.id);
      if (count >= coupon.usage_limit) {
        return success({ valid: false, message: 'This coupon has reached its usage limit.' });
      }
    }

    const discount = calculateDiscount(subtotal, coupon);
    return success({
      valid: true,
      coupon: {
        code: coupon.code,
        type: coupon.type,
        value: coupon.value,
        discountCents: discount,
        discount: discount / 100,
        freeShipping: coupon.type === 'free_shipping'
      },
      message: 'Coupon applied successfully'
    });
  } catch (err) {
    console.error('coupon error:', err.message);
    return serverError('Coupon validation failed');
  }
}

exports.handler = safeHandler(handler);
