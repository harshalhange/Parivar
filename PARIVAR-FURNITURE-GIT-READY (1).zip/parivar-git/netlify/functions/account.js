/**
 * Account API
 * GET    /api/account                  — get account details
 * PATCH  /api/account                  — update account
 * GET    /api/account/addresses        — list addresses
 * POST   /api/account/addresses        — create address
 * PATCH  /api/account/addresses/:id    — update address
 * DELETE /api/account/addresses/:id    — delete address
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, validationError, serverError, unauthorized, notFound, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { validateAddressPayload, sanitizeObject } = require('./lib/validation');
const { getAuthUser } = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) return success({ user: null, message: 'Database not configured' });

  try {
    const db = getClient();
    const user = await getAuthUser(event, db);
    if (!user) return unauthorized('Authentication required');

    const path = event.path || '';
    const isAddresses = path.includes('/addresses');
    const method = event.httpMethod;

    // ---- ADDRESSES ----
    if (isAddresses) {
      const pathParts = path.split('/').filter(Boolean);
      const addressId = pathParts[pathParts.length - 1].match(/^[0-9a-f-]{36}$/) ? pathParts[pathParts.length - 1] : null;

      if (method === 'GET') {
        const { data: addresses, error } = await db.from('addresses')
          .select('*').eq('user_id', user.id).order('is_default', { ascending: false });
        if (error) throw error;
        return success({ addresses: addresses || [] });
      }

      if (method === 'POST') {
        const body = parseBody(event);
        if (!body) return badRequest('Invalid request body');
        const errors = validateAddressPayload(body);
        if (Object.keys(errors).length > 0) return validationError(errors);
        const sanitized = sanitizeObject(body);

        // If setting as default, unset others
        if (sanitized.isDefault) {
          await db.from('addresses').update({ is_default: false }).eq('user_id', user.id);
        }

        const { data: addr, error } = await db.from('addresses').insert({
          user_id: user.id,
          full_name: sanitized.fullName,
          phone: sanitized.phone || null,
          line1: sanitized.line1,
          line2: sanitized.line2 || null,
          city: sanitized.city,
          state: sanitized.state,
          postal_code: sanitized.postalCode,
          country: sanitized.country || 'India',
          is_default: sanitized.isDefault || false
        }).select().single();
        if (error) throw error;
        return success({ address: addr }, 201);
      }

      if (method === 'PATCH' && addressId) {
        const body = parseBody(event);
        if (!body) return badRequest('Invalid request body');
        const sanitized = sanitizeObject(body);

        if (sanitized.isDefault) {
          await db.from('addresses').update({ is_default: false }).eq('user_id', user.id);
        }

        const updateData = {};
        if (sanitized.fullName) updateData.full_name = sanitized.fullName;
        if (sanitized.phone !== undefined) updateData.phone = sanitized.phone;
        if (sanitized.line1) updateData.line1 = sanitized.line1;
        if (sanitized.line2 !== undefined) updateData.line2 = sanitized.line2;
        if (sanitized.city) updateData.city = sanitized.city;
        if (sanitized.state) updateData.state = sanitized.state;
        if (sanitized.postalCode) updateData.postal_code = sanitized.postalCode;
        if (sanitized.country) updateData.country = sanitized.country;
        if (sanitized.isDefault !== undefined) updateData.is_default = sanitized.isDefault;

        const { data: addr, error } = await db.from('addresses').update(updateData).eq('id', addressId).eq('user_id', user.id).select().single();
        if (error || !addr) return notFound('Address not found');
        return success({ address: addr });
      }

      if (method === 'DELETE' && addressId) {
        const { error } = await db.from('addresses').delete().eq('id', addressId).eq('user_id', user.id);
        if (error) return notFound('Address not found');
        return success({ message: 'Address deleted' });
      }
    }

    // ---- ACCOUNT DETAILS ----
    if (method === 'GET') {
      return success({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          phone: user.phone,
          role: user.role,
          created_at: user.created_at,
          last_login_at: user.last_login_at
        }
      });
    }

    if (method === 'PATCH') {
      const body = parseBody(event);
      if (!body) return badRequest('Invalid request body');
      const sanitized = sanitizeObject(body);
      const updateData = {};
      if (sanitized.name) updateData.name = sanitized.name;
      if (sanitized.phone !== undefined) updateData.phone = sanitized.phone;
      const { data: updated, error } = await db.from('users').update(updateData).eq('id', user.id).select().single();
      if (error) throw error;
      return success({ user: { id: updated.id, email: updated.email, name: updated.name, phone: updated.phone, role: updated.role } });
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('account error:', err.message);
    return serverError('Account operation failed');
  }
}

exports.handler = safeHandler(handler);
