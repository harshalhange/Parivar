/**
 * Analytics Events API
 * POST /api/analytics — record an analytics event
 * GET  /api/analytics — list events (admin only)
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, unauthorized, forbidden, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { getAuthUser, getOrCreateSessionId, setGuestSessionCookie } = require('./lib/auth');
const { sanitizeObject } = require('./lib/validation');

const VALID_EVENTS = ['page_view', 'product_view', 'add_to_cart', 'wishlist_add', 'checkout_start', 'purchase', 'search', 'coupon_apply'];

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) return success({ message: 'Event received (db not configured)' });

  try {
    const db = getClient();
    const sessionId = getOrCreateSessionId(event);
    const user = await getAuthUser(event, db);

    if (event.httpMethod === 'POST') {
      const body = parseBody(event);
      if (!body || !body.eventType) return badRequest('eventType is required');
      if (!VALID_EVENTS.includes(body.eventType)) return badRequest('Invalid event type');

      const sanitized = sanitizeObject(body);
      let productId = null;
      if (sanitized.productId) {
        const { data: p } = await db.from('products').select('id').eq('slug', sanitized.productId).single();
        if (p) productId = p.id;
      }

      await db.from('analytics_events').insert({
        event_type: sanitized.eventType,
        user_id: user?.id || null,
        session_id: user ? null : sessionId,
        product_id: productId,
        payload: { ...sanitized, timestamp: new Date().toISOString() }
      });

      return success({ message: 'Event recorded' }, 200, { 'Set-Cookie': setGuestSessionCookie(sessionId) });
    }

    if (event.httpMethod === 'GET') {
      const user = await getAuthUser(event, db);
      if (!user || user.role !== 'admin') return forbidden('Admin access required');
      const { data: events } = await db.from('analytics_events')
        .select('*').order('created_at', { ascending: false }).limit(100);
      return success({ events: events || [] });
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('analytics error:', err.message);
    return serverError('Analytics operation failed');
  }
}

exports.handler = safeHandler(handler);
