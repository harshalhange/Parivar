/**
 * Database Initialization API
 * POST /api/db-init — runs schema migration + seed data
 * This enables zero-manual-setup database deployment
 */
const { getAdminClient, isAdminConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const fs = require('fs');
const path = require('path');
const { safeHandler, parseBody } = require('./lib/security');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isAdminConfigured()) {
    return badRequest('Admin credentials not configured. Set SUPABASE_SERVICE_ROLE_KEY.');
  }

  try {
    const adminDb = getAdminClient();
    const results = { schema: false, seed: false, errors: [], note: '' };

    // Read schema SQL
    let schemaSql = '';
    let seedSql = '';
    try {
      const schemaPath = path.join(__dirname, '..', '..', 'database', 'schema', '001_init.sql');
      schemaSql = fs.readFileSync(schemaPath, 'utf8');
      results.schema = true;
    } catch (e) {
      results.errors.push('Schema file read: ' + e.message);
    }

    // Read seed SQL
    try {
      const seedPath = path.join(__dirname, '..', '..', 'database', 'seeds', '001_seed.sql');
      seedSql = fs.readFileSync(seedPath, 'utf8');
      results.seed = true;
    } catch (e) {
      results.errors.push('Seed file read: ' + e.message);
    }

    // Attempt to execute SQL via Supabase RPC (if available)
    // Note: Supabase doesn't natively support multi-statement SQL via REST API.
    // The recommended approach is to paste the SQL into the Supabase SQL Editor.
    results.note = 'Supabase REST API does not support multi-statement SQL execution. Please copy the contents of database/schema/001_init.sql and database/seeds/001_seed.sql into the Supabase SQL Editor and run them. Alternatively, use the deploy.sh script with the Supabase CLI.';

    return success({
      message: 'Database SQL files are ready. Run them in Supabase SQL Editor.',
      results,
      sqlFiles: ['database/schema/001_init.sql', 'database/seeds/001_seed.sql']
    });
  } catch (err) {
    console.error('db-init error:', err.message);
    return serverError('Database initialization failed');
  }
}

exports.handler = safeHandler(handler);
