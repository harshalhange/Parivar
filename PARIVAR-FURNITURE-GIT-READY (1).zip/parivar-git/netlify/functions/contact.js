/**
 * Contact API
 * POST /api/contact — submit a contact/enquiry message
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, validationError, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody, checkRateLimit, getClientIp } = require('./lib/security');
const { validateContactPayload, sanitizeObject } = require('./lib/validation');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  // Rate limit
  const ip = getClientIp(event);
  const rl = checkRateLimit(ip, 'contact');
  if (!rl.allowed) {
    return { statusCode: 429, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many requests. Please try again later.' } }) };
  }

  const body = parseBody(event);
  if (!body) return badRequest('Invalid request body');

  // Validate
  const errors = validateContactPayload(body);
  if (Object.keys(errors).length > 0) return validationError(errors);

  const sanitized = sanitizeObject(body);

  if (!isConfigured()) {
    return success({ message: 'Message received (database not configured)' });
  }

  try {
    const db = getClient();
    const { data, error } = await db.from('contact_messages').insert({
      name: sanitized.name,
      email: sanitized.email,
      phone: sanitized.phone || null,
      subject: sanitized.subject || null,
      message: sanitized.message,
      source: sanitized.source || 'contact_form',
      status: 'new'
    }).select().single();

    if (error) throw error;
    return success({ message: 'Message sent successfully', id: data.id });
  } catch (err) {
    console.error('contact error:', err.message);
    return serverError('Failed to submit message');
  }
}

exports.handler = safeHandler(handler);
