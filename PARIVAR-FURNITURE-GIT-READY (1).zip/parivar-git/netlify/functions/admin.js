/**
 * Admin API — all admin operations
 * GET    /api/admin/dashboard       — dashboard stats
 * GET    /api/admin/products        — list all products (incl draft/archived)
 * POST   /api/admin/products        — create product
 * PATCH  /api/admin/products/:id    — update product
 * DELETE /api/admin/products/:id    — delete product
 * GET    /api/admin/orders          — list all orders
 * PATCH  /api/admin/orders/:id      — update order status
 * GET    /api/admin/coupons         — list coupons
 * POST   /api/admin/coupons         — create coupon
 * PATCH  /api/admin/coupons/:id     — update coupon
 * GET    /api/admin/reviews         — list pending reviews
 * PATCH  /api/admin/reviews/:id     — approve/reject review
 * GET    /api/admin/customers       — list customers
 * GET    /api/admin/contact         — list contact messages
 * PATCH  /api/admin/contact/:id     — update contact status
 * GET    /api/admin/inventory       — list inventory
 * PATCH  /api/admin/inventory/:id   — update stock
 */
const { getClient, getAdminClient, isConfigured, isAdminConfigured } = require('./lib/db');
const { success, badRequest, notFound, serverError, unauthorized, forbidden, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { getAuthUser } = require('./lib/auth');
const { sanitizeObject } = require('./lib/validation');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) return badRequest('Database not configured');
  if (!isAdminConfigured()) return badRequest('Admin credentials not configured');

  try {
    const db = getClient();
    const adminDb = getAdminClient();
    const user = await getAuthUser(event, db);
    if (!user) return unauthorized('Authentication required');
    if (user.role !== 'admin') return forbidden('Admin access required');

    const path = event.path || '';
    const method = event.httpMethod;
    const params = event.queryStringParameters || {};

    // ---- DASHBOARD ----
    if (path.includes('/dashboard') && method === 'GET') {
      const [{ data: orders }, { data: products }, { data: customers }, { data: reviews }, { data: contacts }] = await Promise.all([
        db.from('orders').select('id, total, fulfillment_status, payment_status, created_at'),
        db.from('products').select('id, stock_quantity'),
        db.from('users').select('id').eq('role', 'customer'),
        db.from('reviews').select('id, status'),
        db.from('contact_messages').select('id, status')
      ]);

      const revenue = (orders || []).reduce((s, o) => s + (o.total || 0), 0);
      const pendingReviews = (reviews || []).filter(r => r.status === 'pending').length;
      const newContacts = (contacts || []).filter(c => c.status === 'new').length;

      return success({
        stats: {
          totalOrders: orders?.length || 0,
          totalRevenue: revenue / 100,
          totalRevenueCents: revenue,
          totalProducts: products?.length || 0,
          totalCustomers: customers?.length || 0,
          pendingReviews,
          newContacts,
          lowStockProducts: (products || []).filter(p => (p.stock_quantity || 0) <= 5).length
        }
      });
    }

    // ---- PRODUCTS (admin) ----
    if (path.includes('/products')) {
      if (method === 'GET') {
        const { data: products } = await db.from('products').select('*').order('created_at', { ascending: true });
        return success({ products: products || [] });
      }
      if (method === 'POST') {
        const body = parseBody(event);
        if (!body) return badRequest('Invalid body');
        const sanitized = sanitizeObject(body);
        const { data: product, error } = await adminDb.from('products').insert({
          slug: sanitized.slug, name: sanitized.name, description: sanitized.description,
          category: sanitized.category, room: sanitized.room, material: sanitized.material,
          fabric: sanitized.fabric, price: sanitized.priceCents || sanitized.price * 100,
          stock_quantity: sanitized.stockQuantity || 0, status: sanitized.status || 'active'
        }).select().single();
        if (error) throw error;
        return success({ product }, 201);
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const sanitized = sanitizeObject(body);
        const { data: product, error } = await adminDb.from('products').update(sanitized).eq('id', id).select().single();
        if (error || !product) return notFound('Product not found');
        return success({ product });
      }
      if (method === 'DELETE') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        await adminDb.from('products').delete().eq('id', id);
        return success({ message: 'Product deleted' });
      }
    }

    // ---- ORDERS (admin) ----
    if (path.includes('/orders')) {
      if (method === 'GET') {
        const { data: orders } = await db.from('orders').select('*, order_items(*)').order('created_at', { ascending: false });
        return success({ orders: orders || [] });
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const updateData = {};
        if (body.fulfillmentStatus) updateData.fulfillment_status = body.fulfillmentStatus;
        if (body.paymentStatus) updateData.payment_status = body.paymentStatus;
        const { data: order, error } = await adminDb.from('orders').update(updateData).eq('id', id).select().single();
        if (error || !order) return notFound('Order not found');
        // Add status history
        if (body.fulfillmentStatus) {
          await adminDb.from('order_status_history').insert({ order_id: id, status: body.fulfillmentStatus, note: body.note || null });
        }
        return success({ order });
      }
    }

    // ---- COUPONS (admin) ----
    if (path.includes('/coupons')) {
      if (method === 'GET') {
        const { data: coupons } = await db.from('coupons').select('*').order('created_at', { ascending: true });
        return success({ coupons: coupons || [] });
      }
      if (method === 'POST') {
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const { data: coupon, error } = await adminDb.from('coupons').insert({
          code: body.code.toUpperCase(), type: body.type, value: body.value || 0,
          minimum_order: body.minimumOrderCents || 0, usage_limit: body.usageLimit,
          per_user_limit: body.perUserLimit || 1, active: body.active !== false
        }).select().single();
        if (error) throw error;
        return success({ coupon }, 201);
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const { data: coupon, error } = await adminDb.from('coupons').update(body).eq('id', id).select().single();
        if (error || !coupon) return notFound('Coupon not found');
        return success({ coupon });
      }
    }

    // ---- REVIEWS (admin) ----
    if (path.includes('/reviews')) {
      if (method === 'GET') {
        const { data: reviews } = await db.from('reviews')
          .select('*, products!inner(slug, name), users!inner(name, email)')
          .order('created_at', { ascending: false });
        return success({ reviews: reviews || [] });
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const { data: review, error } = await adminDb.from('reviews').update({ status: body.status }).eq('id', id).select().single();
        if (error || !review) return notFound('Review not found');
        return success({ review });
      }
    }

    // ---- CUSTOMERS (admin) ----
    if (path.includes('/customers') && method === 'GET') {
      const { data: customers } = await db.from('users').select('id, email, name, phone, role, created_at, last_login_at').eq('role', 'customer').order('created_at', { ascending: false });
      return success({ customers: customers || [] });
    }

    // ---- CONTACT (admin) ----
    if (path.includes('/contact')) {
      if (method === 'GET') {
        const { data: messages } = await db.from('contact_messages').select('*').order('created_at', { ascending: false });
        return success({ messages: messages || [] });
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const { data: msg, error } = await adminDb.from('contact_messages').update({ status: body.status }).eq('id', id).select().single();
        if (error || !msg) return notFound('Message not found');
        return success({ message: msg });
      }
    }

    // ---- INVENTORY (admin) ----
    if (path.includes('/inventory')) {
      if (method === 'GET') {
        const { data: inventory } = await db.from('inventory')
          .select('*, products!inner(slug, name)').order('updated_at', { ascending: false });
        return success({ inventory: inventory || [] });
      }
      if (method === 'PATCH') {
        const pathParts = path.split('/'); const id = pathParts[pathParts.length - 1];
        const body = parseBody(event); if (!body) return badRequest('Invalid body');
        const updateData = {};
        if (body.availableQty !== undefined) updateData.available_qty = body.availableQty;
        if (body.lowStockThreshold !== undefined) updateData.low_stock_threshold = body.lowStockThreshold;
        if (body.availableQty !== undefined) {
          updateData.stock_status = body.availableQty === 0 ? 'out_of_stock' : (body.availableQty <= (body.lowStockThreshold || 5) ? 'low_stock' : 'in_stock');
        }
        const { data: inv, error } = await adminDb.from('inventory').update(updateData).eq('id', id).select().single();
        if (error || !inv) return notFound('Inventory not found');
        // Sync product stock_quantity
        await adminDb.from('products').update({ stock_quantity: inv.available_qty }).eq('id', inv.product_id);
        return success({ inventory: inv });
      }
    }

    return notFound('Admin endpoint not found');
  } catch (err) {
    console.error('admin error:', err.message);
    return serverError('Admin operation failed');
  }
}

exports.handler = safeHandler(handler);
