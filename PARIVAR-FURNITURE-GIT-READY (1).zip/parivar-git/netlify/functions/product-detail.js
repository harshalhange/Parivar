/**
 * GET /api/products/:id — Get single product by slug
 * Also handles: GET /api/products?id=wooden-3-seater-sofa
 */
const { getClient, isConfigured } = require('./lib/db');
const { dbProductToFrontend, getProductImages } = require('./lib/products');
const { success, notFound, serverError, handleOptions } = require('./lib/responses');
const { safeHandler } = require('./lib/security');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isConfigured()) {
    return notFound('Database not configured');
  }

  try {
    const db = getClient();
    const params = event.queryStringParameters || {};
    const slug = params.id || (event.path || '').replace(/\/api\/products\/?/, '');

    if (!slug) {
      return notFound('Product ID is required');
    }

    const { data: product, error } = await db.from('products')
      .select('*')
      .eq('slug', slug)
      .eq('status', 'active')
      .single();

    if (error || !product) {
      return notFound('Product not found');
    }

    const images = await getProductImages(db, product.id);

    // Fetch variants if any
    const { data: variants } = await db.from('product_variants')
      .select('*')
      .eq('product_id', product.id);

    // Fetch inventory
    const { data: inventory } = await db.from('inventory')
      .select('*')
      .eq('product_id', product.id)
      .single();

    const productData = dbProductToFrontend(product, images);
    productData.variants = variants || [];
    productData.stock = inventory ? {
      available: inventory.available_qty,
      status: inventory.stock_status
    } : null;

    return success({ product: productData });
  } catch (err) {
    console.error('product detail error:', err.message);
    return serverError('Failed to fetch product');
  }
}

exports.handler = safeHandler(handler);
