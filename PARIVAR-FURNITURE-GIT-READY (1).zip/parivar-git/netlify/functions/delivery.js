/**
 * Delivery Check API
 * POST /api/delivery/check — check if a postal code is serviceable
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isConfigured()) {
    // Fallback: assume serviceable with defaults
    const body = parseBody(event) || {};
    return success({
      serviceable: true,
      estimatedDelivery: { minDays: 5, maxDays: 7 },
      shippingFee: 4900,
      shippingFeeDisplay: '$49.00',
      message: 'Estimated delivery: 5-7 business days'
    });
  }

  try {
    const db = getClient();
    const body = parseBody(event);
    if (!body || !body.postalCode) return badRequest('postalCode is required');

    const postalCode = body.postalCode.trim();
    const { data: zone, error } = await db.from('delivery_zones')
      .select('*')
      .eq('postal_code', postalCode)
      .single();

    if (error || !zone) {
      // Try partial match (first 3 digits for India)
      const { data: partialZone } = await db.from('delivery_zones')
        .select('*')
        .like('postal_code', postalCode.substring(0, 3) + '%')
        .limit(1)
        .single();

      if (partialZone) {
        return success({
          serviceable: partialZone.serviceable,
          estimatedDelivery: { minDays: partialZone.estimated_min_days, maxDays: partialZone.estimated_max_days },
          shippingFee: partialZone.shipping_fee,
          shippingFeeDisplay: '$' + (partialZone.shipping_fee / 100).toFixed(2),
          city: partialZone.city,
          state: partialZone.state,
          message: `Estimated delivery: ${partialZone.estimated_min_days}-${partialZone.estimated_max_days} business days`
        });
      }

      // Default: serviceable with standard rates
      return success({
        serviceable: true,
        estimatedDelivery: { minDays: 5, maxDays: 10 },
        shippingFee: 4900,
        shippingFeeDisplay: '$49.00',
        message: 'Estimated delivery: 5-10 business days'
      });
    }

    return success({
      serviceable: zone.serviceable,
      estimatedDelivery: { minDays: zone.estimated_min_days, maxDays: zone.estimated_max_days },
      shippingFee: zone.shipping_fee,
      shippingFeeDisplay: '$' + (zone.shipping_fee / 100).toFixed(2),
      city: zone.city,
      state: zone.state,
      message: zone.serviceable
        ? `Estimated delivery: ${zone.estimated_min_days}-${zone.estimated_max_days} business days`
        : 'This area is not currently serviceable'
    });
  } catch (err) {
    console.error('delivery error:', err.message);
    return serverError('Delivery check failed');
  }
}

exports.handler = safeHandler(handler);
