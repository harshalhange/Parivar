/**
 * Orders API
 * GET  /api/orders           — list user's orders
 * GET  /api/orders/:id       — get single order detail
 * GET  /api/orders/:id/tracking — get order tracking
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, notFound, serverError, unauthorized, forbidden, handleOptions } = require('./lib/responses');
const { safeHandler } = require('./lib/security');
const { getAuthUser } = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  if (!isConfigured()) return success({ orders: [] });

  try {
    const db = getClient();
    const user = await getAuthUser(event, db);
    const params = event.queryStringParameters || {};
    const path = event.path || '';

    // Check if this is a tracking request
    const isTracking = path.includes('/tracking');
    const orderIdParam = params.orderId || path.split('/').filter(Boolean).pop();

    // ---- SINGLE ORDER DETAIL ----
    if (orderIdParam && orderIdParam !== 'orders' && !isTracking) {
      const { data: order, error } = await db.from('orders')
        .select('*, order_items(*)')
        .eq('order_number', orderIdParam)
        .single();

      if (error || !order) return notFound('Order not found');

      // Authorization: user must own the order or be admin
      if (user) {
        if (order.user_id !== user.id && user.role !== 'admin') {
          // Check if guest email matches
          if (order.email !== user.email) return forbidden('You do not have access to this order');
        }
      } else if (params.email) {
        if (order.email !== params.email.toLowerCase()) return forbidden('Email does not match order');
      }

      return success({ order: formatOrder(order) });
    }

    // ---- ORDER TRACKING ----
    if (isTracking || params.track) {
      const orderNumber = params.orderId || orderIdParam;
      if (!orderNumber || orderNumber === 'tracking') return notFound('Order ID is required');

      const { data: order, error } = await db.from('orders')
        .select('id, order_number, total, fulfillment_status, created_at, email')
        .eq('order_number', orderNumber)
        .single();

      if (error || !order) return notFound('Order not found');

      // Optional auth check
      if (user && order.email !== user.email && user.role !== 'admin') {
        // Allow lookup with email param
        if (!params.email || params.email.toLowerCase() !== order.email) {
          return forbidden('Email does not match order');
        }
      }

      const { data: history } = await db.from('order_status_history')
        .select('*')
        .eq('order_id', order.id)
        .order('created_at', { ascending: true });

      const steps = ['confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered'];
      const statusIdx = steps.indexOf(order.fulfillment_status);
      const timeline = steps.map((step, i) => {
        const historyEntry = (history || []).find(h => h.status === step);
        return {
          status: step,
          label: step.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
          completed: i <= statusIdx,
          timestamp: historyEntry?.created_at || null,
          note: historyEntry?.note || null
        };
      });

      return success({
        tracking: {
          orderNumber: order.order_number,
          status: order.fulfillment_status,
          total: order.total / 100,
          created_at: order.created_at,
          statusIndex: statusIdx,
          timeline
        }
      });
    }

    // ---- LIST ORDERS ----
    if (!user) return unauthorized('Authentication required to view orders');

    let query = db.from('orders').select('*, order_items(*)').order('created_at', { ascending: false });
    if (user.role !== 'admin') {
      query = query.eq('user_id', user.id);
    }
    const { data: orders, error } = await query;
    if (error) throw error;

    return success({ orders: (orders || []).map(formatOrder) });
  } catch (err) {
    console.error('orders error:', err.message);
    return serverError('Failed to fetch orders');
  }
}

function formatOrder(order) {
  return {
    id: order.order_number,
    orderId: order.id,
    date: order.created_at,
    status: order.fulfillment_status,
    paymentStatus: order.payment_status,
    customer_name: order.customer_name,
    email: order.email,
    phone: order.phone,
    subtotal: order.subtotal / 100,
    discount: order.discount / 100,
    shipping: order.shipping / 100,
    tax: order.tax / 100,
    total: order.total / 100,
    currency: order.currency,
    coupon_code: order.coupon_code,
    payment_method: order.payment_method,
    shipping_address: order.shipping_address,
    order_note: order.order_note,
    items: (order.order_items || []).map(i => ({
      name: i.product_name_snapshot,
      quantity: i.quantity,
      price: i.unit_price_snapshot / 100,
      lineTotal: i.line_total / 100
    }))
  };
}

exports.handler = safeHandler(handler);
