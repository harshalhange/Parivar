/**
 * Reviews API
 * GET  /api/reviews?productId=wooden-3-seater-sofa  — list approved reviews
 * POST /api/reviews                                  — submit a review
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, validationError, serverError, unauthorized, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { validateReviewPayload, sanitizeObject } = require('./lib/validation');
const { getAuthUser } = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) {
    return success({ reviews: [] });
  }

  try {
    const db = getClient();

    if (event.httpMethod === 'GET') {
      const params = event.queryStringParameters || {};
      if (!params.productId) return badRequest('productId is required');

      const { data: product } = await db.from('products').select('id').eq('slug', params.productId).single();
      if (!product) return badRequest('Product not found');

      const { data: reviews, error } = await db.from('reviews')
        .select('id, rating, title, body, verified_purchase, created_at, users!inner(name)')
        .eq('product_id', product.id)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return success({
        reviews: (reviews || []).map(r => ({
          id: r.id,
          rating: r.rating,
          title: r.title,
          body: r.body,
          verifiedPurchase: r.verified_purchase,
          author: r.users?.name || 'Anonymous',
          date: r.created_at
        }))
      });
    }

    if (event.httpMethod === 'POST') {
      const user = await getAuthUser(event, db);
      if (!user) return unauthorized('You must be logged in to leave a review');

      const body = parseBody(event);
      if (!body) return badRequest('Invalid request body');

      const errors = validateReviewPayload(body);
      if (Object.keys(errors).length > 0) return validationError(errors);

      const sanitized = sanitizeObject(body);
      const { data: product } = await db.from('products').select('id').eq('slug', sanitized.productId).single();
      if (!product) return badRequest('Product not found');

      // Check verified purchase — does user have a completed order with this product?
      let verified = false;
      const { data: userOrders } = await db.from('orders')
        .select('id')
        .eq('user_id', user.id)
        .in('fulfillment_status', ['delivered', 'shipped', 'out_for_delivery']);
      if (userOrders && userOrders.length > 0) {
        const orderIds = userOrders.map(o => o.id);
        const { data: orderItem } = await db.from('order_items')
          .select('id')
          .eq('product_id', product.id)
          .in('order_id', orderIds)
          .limit(1);
        verified = orderItem && orderItem.length > 0;
      }

      const { data: review, error } = await db.from('reviews').insert({
        product_id: product.id,
        user_id: user.id,
        order_id: null,
        rating: sanitized.rating,
        title: sanitized.title || null,
        body: sanitized.body || null,
        verified_purchase: verified,
        status: 'pending'
      }).select().single();

      if (error) throw error;
      return success({ message: 'Review submitted and pending approval', id: review.id, verifiedPurchase: verified });
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('reviews error:', err.message);
    return serverError('Reviews operation failed');
  }
}

exports.handler = safeHandler(handler);
