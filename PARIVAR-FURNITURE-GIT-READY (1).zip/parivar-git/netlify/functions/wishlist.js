/**
 * Wishlist API — GET/POST/DELETE
 * GET    /api/wishlist              — get wishlist
 * POST   /api/wishlist              — add product to wishlist
 * DELETE /api/wishlist?productId=x  — remove product
 * DELETE /api/wishlist               — clear wishlist
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody } = require('./lib/security');
const { getAuthUser, getOrCreateSessionId, setGuestSessionCookie } = require('./lib/auth');

async function getOrCreateWishlist(db, userId, sessionId) {
  let query = db.from('wishlists').select('*');
  if (userId) query = query.eq('user_id', userId);
  else query = query.eq('session_id', sessionId);
  query = query.single();

  const { data, error } = await query;
  if (error || !data) {
    const payload = { user_id: userId, session_id: userId ? null : sessionId };
    const { data: newWl, error: createErr } = await db.from('wishlists').insert(payload).select().single();
    if (createErr) throw createErr;
    return { ...newWl, wishlist_items: [] };
  }
  return data;
}

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();

  if (!isConfigured()) {
    return success({ wishlist: { items: [] }, productIds: [] });
  }

  try {
    const db = getClient();
    const sessionId = getOrCreateSessionId(event);
    const user = await getAuthUser(event, db);
    const userId = user?.id || null;
    const wishlist = await getOrCreateWishlist(db, userId, sessionId);

    if (event.httpMethod === 'GET') {
      const { data: items } = await db.from('wishlist_items')
        .select('product_id, products!inner(slug)')
        .eq('wishlist_id', wishlist.id);
      const productIds = (items || []).map(i => i.products?.slug).filter(Boolean);
      return success({ productIds, items: productIds }, 200, { 'Set-Cookie': setGuestSessionCookie(sessionId) });
    }

    if (event.httpMethod === 'POST') {
      const body = parseBody(event);
      if (!body || !body.productId) return badRequest('productId is required');
      const { data: product } = await db.from('products').select('id').eq('slug', body.productId).single();
      if (!product) return badRequest('Product not found');

      await db.from('wishlist_items').upsert({
        wishlist_id: wishlist.id,
        product_id: product.id
      }).select();
      return success({ message: 'Added to wishlist', productId: body.productId });
    }

    if (event.httpMethod === 'DELETE') {
      const params = event.queryStringParameters || {};
      if (params.productId) {
        const { data: product } = await db.from('products').select('id').eq('slug', params.productId).single();
        if (product) {
          await db.from('wishlist_items').delete().eq('wishlist_id', wishlist.id).eq('product_id', product.id);
        }
        return success({ message: 'Removed from wishlist', productId: params.productId });
      } else {
        await db.from('wishlist_items').delete().eq('wishlist_id', wishlist.id);
        return success({ message: 'Wishlist cleared' });
      }
    }

    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  } catch (err) {
    console.error('wishlist error:', err.message);
    return serverError('Wishlist operation failed');
  }
}

exports.handler = safeHandler(handler);
