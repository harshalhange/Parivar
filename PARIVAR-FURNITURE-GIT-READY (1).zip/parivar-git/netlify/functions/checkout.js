/**
 * Checkout API — Server-Authoritative Order Creation
 * POST /api/checkout
 *
 * The backend is authoritative for ALL money calculations:
 * - Validates cart items against real product prices
 * - Validates stock availability
 * - Calculates subtotal, discount, shipping, tax, total
 * - Creates order with price snapshots
 * - Updates inventory
 *
 * NEVER trusts frontend-provided prices, totals, or stock.
 */
const { getClient, isConfigured } = require('./lib/db');
const { success, badRequest, validationError, serverError, handleOptions } = require('./lib/responses');
const { safeHandler, parseBody, generateOrderNumber, checkRateLimit, getClientIp } = require('./lib/security');
const { validateCheckoutPayload, sanitizeObject } = require('./lib/validation');
const { calculateOrderTotal } = require('./lib/money');
const { getAuthUser, getOrCreateSessionId, setGuestSessionCookie } = require('./lib/auth');

async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return handleOptions();
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed' } }) };
  }

  // Rate limit
  const ip = getClientIp(event);
  const rl = checkRateLimit(ip, 'checkout');
  if (!rl.allowed) return { statusCode: 429, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ success: false, error: { code: 'RATE_LIMITED', message: 'Too many checkout attempts. Try later.' } }) };

  if (!isConfigured()) {
    return badRequest('Database not configured. Set up Supabase credentials first.');
  }

  try {
    const db = getClient();
    const sessionId = getOrCreateSessionId(event);
    const user = await getAuthUser(event, db);

    const body = parseBody(event);
    if (!body) return badRequest('Invalid request body');

    // Validate input
    const errors = validateCheckoutPayload(body);
    if (Object.keys(errors).length > 0) return validationError(errors);

    const sanitized = sanitizeObject(body);

    // ---- SERVER-AUTHORITATIVE PRICE CALCULATION ----
    // Resolve each cart item's price from the database
    const serverItems = [];
    for (const item of sanitized.items) {
      const { data: product, error } = await db.from('products')
        .select('id, slug, name, price, stock_quantity, status')
        .eq('slug', item.productId || item.id)
        .eq('status', 'active')
        .single();
      if (error || !product) {
        return badRequest(`Product not found: ${item.productId || item.id}`);
      }

      // Check stock
      if (product.stock_quantity < item.quantity) {
        return badRequest(`Some items are no longer available in the requested quantity. (${product.name})`);
      }

      serverItems.push({
        product_id: product.id,
        product_name_snapshot: product.name,
        unit_price_snapshot: product.price,  // in cents
        quantity: item.quantity,
        image_snapshot: item.image || null
      });
    }

    // ---- COUPON VALIDATION ----
    let coupon = null;
    let couponRecord = null;
    if (sanitized.couponCode) {
      const { data: couponData } = await db.from('coupons')
        .select('*')
        .eq('code', sanitized.couponCode.toUpperCase())
        .eq('active', true)
        .single();
      if (couponData) {
        coupon = couponData;
        couponRecord = couponData;
      }
    }

    // ---- DELIVERY ZONE ----
    let deliveryZone = null;
    if (sanitized.zip) {
      const { data: zone } = await db.from('delivery_zones')
        .select('*')
        .eq('postal_code', sanitized.zip)
        .single();
      if (zone) deliveryZone = zone;
    }

    // ---- CALCULATE TOTALS (server-authoritative) ----
    const totals = calculateOrderTotal(serverItems, coupon, deliveryZone);

    // ---- CREATE ORDER ----
    const orderNumber = generateOrderNumber();
    const shippingAddress = {
      fullName: sanitized.fullName,
      line1: sanitized.address,
      line2: sanitized.address2 || null,
      city: sanitized.city,
      state: sanitized.state,
      postalCode: sanitized.zip,
      country: sanitized.country || 'United States'
    };

    const { data: order, error: orderError } = await db.from('orders').insert({
      order_number: orderNumber,
      user_id: user?.id || null,
      guest_email: user ? null : sanitized.email,
      customer_name: sanitized.fullName,
      phone: sanitized.phone,
      email: sanitized.email,
      subtotal: totals.subtotal,
      discount: totals.discount,
      shipping: totals.shipping,
      tax: totals.tax,
      total: totals.total,
      currency: 'USD',
      coupon_code: coupon ? coupon.code : null,
      payment_method: sanitized.paymentMethod || 'whatsapp',
      payment_status: 'pending',
      fulfillment_status: 'confirmed',
      shipping_address: shippingAddress,
      billing_address: sanitized.differentBilling ? sanitized.billingAddress : null,
      order_note: sanitized.note || null
    }).select().single();

    if (orderError) throw orderError;

    // ---- CREATE ORDER ITEMS (with price snapshots) ----
    const orderItems = serverItems.map(item => ({
      order_id: order.id,
      product_id: item.product_id,
      product_name_snapshot: item.product_name_snapshot,
      unit_price_snapshot: item.unit_price_snapshot,
      quantity: item.quantity,
      line_total: item.unit_price_snapshot * item.quantity,
      image_snapshot: item.image_snapshot
    }));

    const { error: itemsError } = await db.from('order_items').insert(orderItems);
    if (itemsError) throw itemsError;

    // ---- CREATE STATUS HISTORY ----
    await db.from('order_status_history').insert({
      order_id: order.id,
      status: 'confirmed',
      note: 'Order placed successfully'
    });

    // ---- UPDATE INVENTORY ----
    for (const item of serverItems) {
      // Decrement stock
      await db.rpc('decrement_stock', { p_product_id: item.product_id, p_quantity: item.quantity }).catch(() => {
        // Fallback if RPC doesn't exist — do direct update
        return db.from('products')
          .update({ stock_quantity: db.raw('stock_quantity - ' + item.quantity) })
          .eq('id', item.product_id);
      });

      // Update inventory table
      const { data: inv } = await db.from('inventory').select('*').eq('product_id', item.product_id).single();
      if (inv) {
        const newAvailable = Math.max(0, inv.available_qty - item.quantity);
        const newSold = inv.sold_qty + item.quantity;
        const newStatus = newAvailable === 0 ? 'out_of_stock' : (newAvailable <= inv.low_stock_threshold ? 'low_stock' : 'in_stock');
        await db.from('inventory').update({
          available_qty: newAvailable,
          sold_qty: newSold,
          stock_status: newStatus
        }).eq('id', inv.id);

        // Also sync product stock_quantity
        await db.from('products').update({ stock_quantity: newAvailable }).eq('id', item.product_id);
      }
    }

    // ---- RECORD COUPON REDEMPTION ----
    if (couponRecord) {
      await db.from('coupon_redemptions').insert({
        coupon_id: couponRecord.id,
        user_id: user?.id || null,
        session_id: user ? null : sessionId,
        order_id: order.id
      });
    }

    // ---- BUILD WHATSAPP MESSAGE (if payment method is whatsapp) ----
    let whatsappUrl = null;
    if ((sanitized.paymentMethod || 'whatsapp') === 'whatsapp') {
      const whatsappNumber = process.env.WHATSAPP_NUMBER || '919876543210';
      let msg = `*PARIVAR FURNITURE ORDER*\n\n`;
      msg += `*Order Number:* ${orderNumber}\n`;
      msg += `*Customer:* ${sanitized.fullName}\n`;
      msg += `*Phone:* ${sanitized.phone}\n`;
      msg += `*Email:* ${sanitized.email}\n\n`;
      msg += `*Shipping Address:*\n${sanitized.address}\n${sanitized.city}, ${sanitized.state} ${sanitized.zip}\n${sanitized.country || ''}\n\n`;
      if (sanitized.note) msg += `*Note:* ${sanitized.note}\n\n`;
      msg += `*Items:*\n`;
      serverItems.forEach(i => {
        const lineTotal = (i.unit_price_snapshot * i.quantity / 100).toFixed(2);
        msg += `• ${i.product_name_snapshot} x${i.quantity} — $${lineTotal}\n`;
      });
      msg += `\nSubtotal: $${(totals.subtotal / 100).toFixed(2)}\n`;
      if (totals.discount > 0) msg += `Discount: -$${(totals.discount / 100).toFixed(2)}\n`;
      msg += `Shipping: ${totals.shipping === 0 ? 'FREE' : '$' + (totals.shipping / 100).toFixed(2)}\n`;
      msg += `Tax: $${(totals.tax / 100).toFixed(2)}\n`;
      msg += `*Total: $${(totals.total / 100).toFixed(2)}*\n\nPlease confirm this order.`;
      whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(msg)}`;
    }

    // ---- CLEAR SERVER-SIDE CART (if exists) ----
    if (user) {
      const { data: cart } = await db.from('carts').select('id').eq('user_id', user.id).single();
      if (cart) {
        await db.from('cart_items').delete().eq('cart_id', cart.id);
        await db.from('carts').update({ subtotal: 0, total: 0 }).eq('id', cart.id);
      }
    }

    return success({
      order: {
        id: order.id,
        orderNumber,
        subtotal: totals.subtotal / 100,
        subtotalCents: totals.subtotal,
        discount: totals.discount / 100,
        discountCents: totals.discount,
        shipping: totals.shipping / 100,
        shippingCents: totals.shipping,
        tax: totals.tax / 100,
        taxCents: totals.tax,
        total: totals.total / 100,
        totalCents: totals.total,
        currency: 'USD',
        items: orderItems.map(i => ({
          name: i.product_name_snapshot,
          quantity: i.quantity,
          price: i.unit_price_snapshot / 100,
          lineTotal: i.line_total / 100
        })),
        shippingAddress,
        status: 'confirmed'
      },
      whatsappUrl
    }, 201, { 'Set-Cookie': setGuestSessionCookie(sessionId) });
  } catch (err) {
    console.error('checkout error:', err.message);
    return serverError('Checkout failed: ' + (err.message || 'unknown error'));
  }
}

exports.handler = safeHandler(handler);
